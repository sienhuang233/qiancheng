import test from 'node:test';
import assert from 'node:assert/strict';
import {homeChatHidden} from '../public/engines/navigation.mjs';

test('首页在未开始对话时隐藏对话栏', () => {
  assert.equal(homeChatHidden('home', false), true);
  assert.equal(homeChatHidden('intro', false), true);
});

test('首页一旦开始对话就显示对话栏（即“跳转对话框”）', () => {
  assert.equal(homeChatHidden('home', true), false);
  assert.equal(homeChatHidden('intro', true), false);
});

test('其他业务页始终显示对话栏，与 chatOpen 无关', () => {
  for (const page of ['goal', 'bills', 'debts', 'security']) {
    assert.equal(homeChatHidden(page, false), false, `${page} 不该隐藏对话`);
    assert.equal(homeChatHidden(page, true), false, `${page} 不该隐藏对话`);
  }
});
