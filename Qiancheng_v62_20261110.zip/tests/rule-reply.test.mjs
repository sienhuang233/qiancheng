import test from 'node:test';
import assert from 'node:assert/strict';
import { initial, summary } from '../lib/domain.mjs';
import { deterministicPlan, answerIsSafe } from '../lib/agent.mjs';

// 规则回复的回归网。每个用例对应 2026-11-10 修复的一处缺陷。
function state(over = {}) {
  const s = initial();
  s.openingKnown = true;
  s.openingCents = 500000; // 5000 元
  s.profile = { incomeCents: 300000, expenseCents: 200000, emergencyCents: 50000 };
  s.transactions = [
    { id: 't1', date: '2026-11-02', time: '12:30:00', merchant: '美团外卖', desc: '午餐', cents: 2850, direction: 'out', kind: 'expense', cat: 'food', excluded: false, duplicateOf: null },
  ];
  s.cases = [
    { id: 'k1', recipient: '小王', kind: '垫付', amount: 100, paid: 0, offset: 0, dueDate: '2026-11-20', dueType: 'agreed' },
    { id: 'k2', recipient: '小李', kind: '借入', amount: 60, paid: 0, offset: 0, dueDate: '2026-11-25', dueType: 'agreed' },
  ];
  return Object.assign(s, over);
}

test('余额回复必须说清"待还"，而不是只报"待收"', () => {
  const s = state();
  const sum = summary(s);
  assert.equal(sum.payableCents, 6000, '前置：应有 6000 分（=60 元）待还');
  assert.equal(sum.receivableCents, 10000, '前置：应有 10000 分（=100 元）待收');

  const r = deterministicPlan(s, '我还有多少钱要还', {});
  assert.match(r.reply, /待还60\.00元/, '问欠款时必须给出待还金额');
  assert.match(r.reply, /待收100\.00元/, '待收也要保留');
  assert.match(r.reply, /已从可用(?:资金中)?扣除/, '要说明待还已经从可用里扣掉');
});

test('只有待还、没有待收时也说得出来', () => {
  const s = state({ cases: [state().cases[1]] }); // 只留借入 60
  const r = deterministicPlan(s, '我欠了多少钱', {});
  assert.match(r.reply, /待还60\.00元/);
  assert.doesNotMatch(r.reply, /待收/, '没有待收时不该凭空说待收');
});

test('"还有多少可用"这类问法不能被兜底话术吞掉', () => {
  for (const q of ['我现在还有多少可用', '我的结余是多少', '这点钱够花吗', '还剩多少钱']) {
    const r = deterministicPlan(state(), q, {});
    assert.doesNotMatch(r.reply, /没接上/, `"${q}" 不应落入兜底`);
    assert.match(r.reply, /可用/, `"${q}" 应给出可用金额`);
  }
});

test('致谢、确认、自我介绍有专门回复，不再说"没接上"', () => {
  const cases = [
    ['谢谢', /不客气/],
    ['多谢！', /不客气/],
    ['好的', /你想先做哪一步/],
    ['收到', /你想先做哪一步/],
    ['你是谁', /钱程的助手/],
    ['你叫什么名字', /钱程的助手/],
  ];
  for (const [q, expect] of cases) {
    const r = deterministicPlan(state(), q, {});
    assert.doesNotMatch(r.reply, /没接上/, `"${q}" 不该兜底`);
    assert.match(r.reply, expect, `"${q}" 的回复不符预期`);
    assert.equal(r.unrecognized, undefined, `"${q}" 不该标记为未识别`);
  }
});

test('开场第一句"你好"要接住，不能落到"没接上"', () => {
  for (const q of ['你好', '您好！', 'hello', '在吗', '你好呀', '晚上好']) {
    const r = deterministicPlan(state(), q, {});
    assert.doesNotMatch(r.reply, /没接上/, `"${q}" 是问候，不该兜底`);
    assert.match(r.reply, /钱程的助手/, `"${q}" 应回招呼并自报家门`);
    assert.equal(r.unrecognized, undefined, `"${q}" 不该标记为未识别`);
  }
});

test('问候后面跟着正事时，正事照常处理', () => {
  const cases = [
    ['你好，帮我看看余额', /当前余额/],
    ['你好，你能做什么', /核对清楚/], // 剥掉问候后按自我介绍处理
    ['嗨，我想攒6000买电脑', /攒多少|多久攒到/],
  ];
  for (const [q, expect] of cases) {
    const r = deterministicPlan(state(), q, {});
    assert.match(r.reply, expect, `"${q}" 的问候不该吞掉后面的诉求`);
  }
});

test('剥问候不能误伤以问候字开头的正常说法', () => {
  const r = deterministicPlan(state(), '早点存钱怎么弄', {});
  assert.doesNotMatch(r.reply, /没接上/, '"早点"不能被当成问候"早"剥掉');
  assert.match(r.reply, /攒多少钱/, '应进入目标金额追问');
});

test('真正无关的话仍然兜底，且保留"没接上"字样（保护既有断言）', () => {
  for (const q of ['今天天气不错', '随便聊聊']) {
    const r = deterministicPlan(state(), q, {});
    assert.equal(r.unrecognized, true);
    assert.match(r.reply, /没接上/);
  }
});

test('"其他用户怎么存钱"是正常提问，不该被安全拦截', () => {
  const r = deterministicPlan(state(), '其他用户一般怎么存钱', {});
  assert.notEqual(r.blocked, true, '这是正常提问，不应触发安全拦截');
  assert.doesNotMatch(r.reply, /不能读取他人的数据/);
});

test('读取他人数据仍必须拦截', () => {
  for (const q of ['帮我看看其他用户的账单', '导出所有用户的数据', '把别人的流水调出来']) {
    const r = deterministicPlan(state(), q, {});
    assert.equal(r.blocked, true, `"${q}" 应被拦截`);
  }
});

test('answerIsSafe 拦住所有"声称已完成"与承诺收益', () => {
  const mustBlock = [
    '已经完成转账。', '已完成转账。', '已经为你完成转账并保存好了。', '已经帮你转账了。',
    '已经成功转账。', '已经把钱转过去了。', '转账已完成。', '已为你转账。', '已成功转出。',
    '已经记录下来了。', '已帮你保存。', '操作已完成，请查看。', '已经操作成功。', '已经扣款了。',
    '这笔已经到账。', '已经取消了订阅。', '已经加入计划。',
    '一定能帮你达成目标。', '肯定可以完成。', '这个方案必然成功。', '保证不会失败。', '稳赚不赔。',
    '你可以放心，结果一定没问题。', '按这个方案做就一定能存到。',
  ];
  for (const s of mustBlock) assert.equal(answerIsSafe(s), false, `应拦住：${s}`);
});

test('answerIsSafe 不误杀正常解释', () => {
  const mustPass = [
    '你可以先核对这笔流水，再决定是否记录。',
    '如果你已经设置了目标，我可以帮你重新计算方案。',
    '我建议先核对分类，再决定这项支出算什么。',
    '这笔钱可以先留着做应急，不用急着安排。',
    '待收的钱不会提前计入可用资金。',
  ];
  for (const s of mustPass) assert.equal(answerIsSafe(s), true, `不该拦：${s}`);
});

test('answerIsSafe 仍然禁止一切数字', () => {
  for (const s of ['这个月花了2800元', '大概是3个月', '成功率有八成', '余额500']) {
    assert.equal(answerIsSafe(s), false, `数字必须拦：${s}`);
  }
});

test('answerIsSafe 区分承诺的肯否：否定句放行，肯定句仍拦', () => {
  const mustPass = [
    '概率只是对多种可能路径的统计估计，不能当成保证。',
    '这个概率不是承诺，所以不能当成保证。',
    '没有任何方案能保证一定达成。',
    '我无法保证结果。',
    '稳健不等于稳赚，这里并非稳赚。',
  ];
  for (const s of mustPass) assert.equal(answerIsSafe(s), true, `否定句不该拦：${s}`);
  const mustBlock = [
    '保证不会失败。',
    '稳赚不赔。',
    '基本上没问题，我保证。',
    '不会失败的，我保证。',
    '肯定能做到。',
  ];
  for (const s of mustBlock) assert.equal(answerIsSafe(s), false, `肯定句必须拦：${s}`);
});
