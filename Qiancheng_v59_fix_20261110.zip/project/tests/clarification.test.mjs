import test from 'node:test';
import assert from 'node:assert/strict';
import {apply,initial,summary,month} from '../lib/domain.mjs';
import {deterministicPlan,plan} from '../lib/agent.mjs';
import {SUBSCRIPTION_REQUEST} from '../public/engines/subscriptions.mjs';
import {controller} from './helpers/controller.mjs';

const funded=()=>apply(initial(),'profile',{opening:'1000',income:'2000',expense:'1000'}).state;

test('普通用户入口：两个候选金额先追问，补齐后出现待确认草案，口头应答不会执行',async()=>{
 const h=controller(funded()),cash=summary(h.state).cashCents;
 await h.driver.chat('帮我转给小王100元还是200元');
 assert.equal(h.driver.dump().agentContext.draft.name,'小王');
 assert.equal(h.driver.dump().agentContext.draft.amount,'');
 assert.equal(h.driver.dump().pending,null);
 h.driver.render();
 assert.match(h.mount.innerHTML,/待澄清 · 本轮未生成新草案/);
 await h.driver.chat('好的');
 assert.equal(h.calls.filter(c=>c.path==='prepare').length,0);
 await h.driver.chat('200元');
 assert.equal(h.driver.dump().pending.args.name,'小王');
 assert.equal(h.driver.dump().pending.args.amount,'200');
 await h.driver.chat('继续');
 assert.equal(summary(h.state).cashCents,cash);
 assert.equal(h.state.transactions.length,0);
 await h.driver.commitPending();
 assert.equal(summary(h.state).cashCents,cash-20000);
 assert.equal(h.state.transactions.length,1);
});

test('未选操作时重复原问题，原有入口在明确选择后可继续',async()=>{
 const h=controller(funded());
 await h.driver.chat('帮我把500元处理一下');
 const question=h.driver.dump().messages.at(-1).text;
 assert.match(question,/设储蓄目标、核对账单/);
 await h.driver.sendChatInput('');
 assert.equal(h.driver.dump().messages.at(-1).text,question);
 await h.driver.chat('500元');
 assert.equal(h.driver.dump().messages.at(-1).text,question);
 assert.equal(h.calls.filter(c=>c.path==='prepare').length,0);
 await h.driver.chat('我想6个月攒500元');
 assert.equal(h.driver.dump().goalScreen,'goal-review');
 assert.equal(h.state.goal,null);
 await h.driver.commitInlineGoal();
 assert.equal(h.state.goal.targetCents,50000);
});

test('备选对象、期限和日期不会被选中，回复单一答案后接续',()=>{
 const s=funded();
 for(const q of ['转给小王或小李100元','转给他100元']){
  const r=deterministicPlan(s,q);
  assert.equal(r.clarification,true);
  assert.equal(r.proposal,null);
  assert.equal(r.context.stage,'name');
  assert.equal(r.context.draft.amount,'100');
  assert.equal(deterministicPlan(s,'小李',r.context).proposal.args.name,'小李');
 }
 for(const q of ['我想6个月攒5000或6000元','我想6个月攒5千或6千元','我想6个月攒5000-6000元']){
  const r=deterministicPlan(s,q);
  assert.equal(r.clarification,true);
  assert.equal(r.proposal,null);
  assert.equal(r.context.months,6);
  assert.equal(deterministicPlan(s,'6000元',r.context).proposal.args.target,'6000');
 }
 let r=deterministicPlan(s,'我想攒5000元，6到8个月');
 assert.equal(r.proposal,null);
 assert.equal(r.context.target,'5000');
 assert.equal(deterministicPlan(s,'8个月',r.context).proposal.args.months,8);
 r=deterministicPlan(s,'明天还是后天',{intent:'payment_interview',stage:'date',draft:{kind:'垫付',name:'小王',amount:'100'}});
 assert.equal(r.proposal,null);
 assert.equal(r.context.draft.dueDate,'');
 assert.equal(r.context.stage,'date');
 r=deterministicPlan(s,'对方应还40元，整笔总共100元',{intent:'payment_interview',stage:'amount',draft:{kind:'AA',name:'小王'}});
 assert.equal(r.context.draft.amount,'100');
 assert.equal(r.context.draft.receivableAmount,'40');
 assert.equal(r.context.stage,'date');
});

test('否定和程序已识别的歧义挡住模型猜测，模型主动澄清也不会生成草案',async()=>{
 const fetcher=globalThis.fetch,key=process.env.BIGMODEL_API_KEY,model=process.env.BIGMODEL_MODEL;
 try{
  process.env.BIGMODEL_API_KEY='test-only';process.env.BIGMODEL_MODEL='test-only';
  let calls=0,raw={intent:'transfer',recipient:'小王',amount:'100',kind:'普通付款'};
  globalThis.fetch=async()=>{calls++;return {ok:true,json:async()=>({choices:[{message:{content:JSON.stringify(raw)}}]})};};
  const s=funded(),ctx={intent:'payment_interview',stage:'amount',draft:{kind:'普通付款',name:'小王'}};
  const paused=await plan(s,'先别把金额改成200元',ctx);
  assert.equal(paused.proposal,null);
  assert.equal((await plan(s,'200元',paused.context)).proposal,null);
  assert.equal((await plan(s,'转给小王100元还是200元')).proposal,null);
  assert.equal(calls,0);
  raw={intent:'clarify',answer:'你想先核对哪项操作？'};
  const r=await plan(s,'转给小王100元');
  assert.equal(r.clarification,true);
  assert.equal(r.proposal,null);
  assert.equal(r.reply,raw.answer);
  assert.equal(calls,1);
  assert.equal((await plan(s,'好的',r.context)).reply,raw.answer);
  assert.equal(calls,1);
  raw={intent:'reserve',amount:'100'};
  const unsolicited=await plan(s,'手头刚好有100元');
  assert.equal(unsolicited.clarification,true);
  assert.equal(unsolicited.proposal,null);
  assert.match(unsolicited.reply,/用途还需要确认/);
  raw={intent:'people_flow',amount_field:{value:100,quote:'100元'},receivable_field:{value:100,quote:'100元'}};
  const aa=await plan(s,'总共100元',{intent:'payment_interview',stage:'amount',draft:{kind:'AA',name:'小王'}});
  assert.equal(aa.context.stage,'share');
  assert.equal(aa.proposal,null);
 }finally{
  globalThis.fetch=fetcher;
  for(const [name,value] of [['BIGMODEL_API_KEY',key],['BIGMODEL_MODEL',model]]){
   if(value===undefined)delete process.env[name];else process.env[name]=value;
  }
 }
});

test('核对订阅时，假设取消只询问处理意图',async()=>{
 const s=apply(initial(),'sample_bill',{}).state,billPeriod=month();
 const start=await plan(s,SUBSCRIPTION_REQUEST,{},null,[],{billPeriod,taskChannel:'subscription-start'});
 const result=await plan(s,'如果取消腾讯视频会怎样？',start.context,null,[],{billPeriod});
 assert.equal(result.proposal,null);
 assert.equal(result.clarification,true);
 assert.match(result.reply,/预览取消，还是保留/);
});
