import test from 'node:test';
import assert from 'node:assert/strict';
import {normalize,csvRows} from '../public/engines/import.mjs';

const HEADER='交易时间,交易类型,交易对方,商品,收/支,金额(元),当前状态,交易单号';

test('导入报错给的是文件真实行号，前面的说明行和空行不造成偏移',()=>{
 const file=[
  '微信支付账单明细,,,,,,,',
  '起始时间：[2026-09-01 00:00:00],,,,,,,',
  ',,,,,,,',
  '注：,,,,,,,',
  ',,,,,,,',
  '----------------------微信支付账单明细列表--------------------,,,,,,,',
  HEADER,
  '2026-09-02 12:30:00,商户消费,美团外卖,午餐,支出,¥28.50,支付成功,TX1',
  ',,,,,,,',
  '2026-09-03 09:15:00,商户消费,肯德基,早餐,支出,-21.00,支付成功,TX2',
 ];
 try{normalize(csvRows(file.join('\n')));assert.fail('负号金额应被拒绝');}
 catch(e){assert.match(e.message,/文件第 10 行/);}
});

test('支付宝导出的「类型」列被识别为原始类型，与微信的「交易类型」等价',()=>{
 const alipay=[
  '交易号 ,商家订单号 ,交易创建时间 ,付款时间 ,交易来源地 ,类型 ,交易对方 ,商品名称 ,金额（元） ,收/支 ,交易状态 ,备注 ,',
  '2026080122001 ,T001 ,2026-08-01 07:30:12 ,2026-08-01 07:30:20 ,其他 ,即时到账交易 ,肯德基 ,早餐 ,21.00 ,支出 ,交易成功 , ,',
  '2026080222002 ,T002 ,2026-08-02 09:00:00 ,2026-08-02 09:00:05 ,其他 ,转账 ,小王 ,转账 ,100.00 ,支出 ,交易成功 , ,',
 ];
 const r=normalize(csvRows(alipay.join('\n')));
 assert.equal(r.rows.length,2);
 assert.equal(r.rows[0].rawType,'即时到账交易');
 assert.equal(r.rows[1].rawType,'转账');
 assert.equal(r.rows[1].externalId,'2026080222002');
});

test('已付款的「等待确认收货」保留，未付的「等待付款」才跳过',()=>{
 const csv=[
  HEADER,
  '2026-09-01 10:00:00,商户消费,淘宝,已付款待收货,支出,88.00,等待确认收货,TX1',
  '2026-09-02 10:00:00,商户消费,淘宝,下单未付,支出,66.00,等待付款,TX2',
  '2026-09-03 10:00:00,商户消费,某店,已关闭,支出,9.00,交易关闭,TX3',
 ].join('\n');
 const r=normalize(csvRows(csv));
 assert.equal(r.rows.length,1);
 assert.equal(r.rows[0].amount,'88.00');
 assert.equal(r.skipped,2);
});

test('有内容但缺金额的行单独计数，不静默丢弃也不拖垮整批',()=>{
 const csv=[
  HEADER,
  '2026-09-02 12:00:00,商户消费,美团,午餐,支出,28.50,支付成功,TX1',
  '2026-09-03 12:00:00,商户消费,缺金额,,,,支付成功,TX2',
  '2026-09-04 12:00:00,商户消费,肯德基,早餐,支出,21.00,支付成功,TX3',
 ].join('\n');
 const r=normalize(csvRows(csv));
 assert.equal(r.rows.length,2);
 assert.equal(r.blank,1);
 assert.equal(r.skipped,0);
});

test('整份账单全是缺金额行时给出可读提示',()=>{
 const csv=[HEADER,'2026-09-02 12:00:00,商户消费,美团,午餐,支出,,支付成功,TX1'].join('\n');
 assert.throws(()=>normalize(csvRows(csv)),/1 行有内容但缺少金额/);
});
