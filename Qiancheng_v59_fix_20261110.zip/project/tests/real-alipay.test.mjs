import test from 'node:test';
import assert from 'node:assert/strict';
import {normalize,csvRows} from '../public/engines/import.mjs';
import {classify,setRules} from '../public/engines/classifier.mjs';
import {initial,apply,summary} from '../lib/domain.mjs';

/* 支付宝手机版导出的真实列结构（12 列，GBK 原文已转码）。
   这里用虚构商户与金额，只保留真实账单里出现过的列名与取值。 */
const AH='交易时间,交易分类,交易对方,对方账号,商品说明,收/支,金额,收/付款方式,交易状态,交易订单号,商家订单号,备注';
const alipay=rows=>normalize(csvRows([AH,...rows].join('\r\n')));

test('支付宝 12 列真实格式：表头、日期斜杠、带引号单号都能解析',()=>{
 const r=alipay([
  '2026/11/9 9:08,文化休闲,某**店,193******70,卡牌 等多件,支出,38.3,某银行储蓄卡(0000),等待确认收货,"2026110900000000000000000001\t","T200P5111111111111111111\t",',
  '2026/11/7 17:15,退款,138******00,138******00,退款-代付,不计收支,19.4,某银行储蓄卡(0000),退款成功,"2026110700000000000000000001_20261107000000000000000000000001\t","2026110700000000000000000001\t",',
 ]);
 assert.equal(r.rows.length,2);
 assert.equal(r.rows[0].date,'2026-11-09');
 assert.equal(r.rows[0].time,'09:08:00');
 assert.equal(r.rows[0].amount,'38.3');
 assert.equal(r.rows[0].direction,'out');
 assert.equal(r.rows[0].rawCat,'文化休闲');
 assert.equal(r.rows[0].externalId,'2026110900000000000000000001');
 assert.equal(r.rows[1].direction,'neutral');
});

test('0 元交易不是脏数据：全额红包抵扣、会员试用都要导入',()=>{
 const r=alipay([
  '2026/8/13 16:34,文化休闲,某网盘,gzo***@ucweb.com,3天试用(某网盘SVIP会员),支出,0,红包,交易成功,"2026081300000000000000000001\t","544444444444444444\t",',
 ]);
 assert.equal(r.rows.length,1);
 assert.equal(r.rows[0].amount,'0');
 const cls=classify({merchant:'某网盘',desc:'3天试用(某网盘SVIP会员)',rawCat:'文化休闲',rawType:''});
 assert.equal(cls.cat,'subs','0 元试用是订阅线索，不能被丢掉');
});

test('两笔同金额同时刻但单号不同，不算重复扣款',()=>{
 const r=alipay([
  '2026/10/20 17:20,退款,t***9,139******00,退款-蛋挞券,不计收支,0.06,某银行储蓄卡(0000),退款成功,"2026101900000000000000000001_5222222222222222222\t","T200P5222222222222222222\t",',
  '2026/10/20 17:20,退款,t***9,139******00,退款-蛋挞券,不计收支,0.06,某银行储蓄卡(0000),退款成功,"2026101900000000000000000002_5333333333333333333\t","T200P5333333333333333333\t",',
 ]);
 const out=apply(initial(),'import',{rows:r.rows,source:'alipay'}).state;
 assert.equal(out.transactions.length,2);
 assert.equal(out.transactions.filter(t=>t.duplicateOf).length,0,'单号不同就是两笔真实交易');
});

test('真没单号的同金额同商户流水，才标为疑似重复',()=>{
 const r=alipay([
  '2026/10/20 17:20,日用百货,某某小卖部,/,矿泉水,支出,2,零钱,交易成功,,,',
  '2026/10/20 17:20,日用百货,某某小卖部,/,矿泉水,支出,2,零钱,交易成功,,,',
 ]);
 const out=apply(initial(),'import',{rows:r.rows,source:'alipay'}).state;
 assert.equal(out.transactions.length,2);
 assert.equal(out.transactions.filter(t=>t.duplicateOf).length,1);
});

test('真实账单里的分类抽样：日用百货、亲友代付、纸巾不误判为交通',()=>{
 setRules([]);
 assert.equal(classify({merchant:'校园连锁超市',desc:'80613042B455555555555555555-某大学店',rawCat:'日用百货',rawType:''}).cat,'shop');
 assert.equal(classify({merchant:'138******00',desc:'代付',rawCat:'亲友代付',rawType:''}).cat,'person');
 assert.equal(classify({merchant:'某某(**某)',desc:'本科 某班 某某',rawCat:'转账红包',rawType:''}).cat,'person');
 assert.equal(classify({merchant:'全球**店',desc:'维达超韧手帕纸4层24包便携出行装学生随身小包擦手卫生纸巾',rawCat:'日用百货',rawType:''}).cat,'shop','「便携出行装」里的「出行」不该判成通勤');
 assert.equal(classify({merchant:'哈啰出行',desc:'哈啰单车骑行',rawCat:'交通出行',rawType:''}).cat,'transit');
});

test('跨来源导入同一批流水：标疑似重复但不重复计入消费',()=>{
 const r=alipay(['2026/11/2 7:39,餐饮美食,某某面馆,/,热干面,支出,6.5,零钱,交易成功,"T1\t",,']);
 const s1=apply(initial(),'import',{rows:r.rows,source:'alipay'}).state;
 const r2=apply(s1,'import',{rows:r.rows,source:'wechat'});
 assert.equal(r2.result.added,1);
 assert.equal(r2.result.possible,1);
 assert.equal(summary(r2.state,'2026-11').expenseCents,650,'换来源导入不应让消费翻倍');
});
