import test from 'node:test';
import assert from 'node:assert/strict';
import {apply,initial,summary,day,month} from '../lib/domain.mjs';
import {analyzeBills,billPlanPreview} from '../public/engines/bill-analysis.mjs';
import {coachScenario} from '../public/engines/coach-scenario.mjs';
import {simulationComparison} from '../public/engines/goal.mjs';
import {controller} from './helpers/controller.mjs';

const change=(state,type,args={})=>apply(structuredClone(state),type,args).state;
const view=state=>({state,summary:summary(state)});

function student(target,months){
 let s=change(initial(),'goal',{target,months});
 s=change(s,'guided_demo');
 return change(s,'coach',{place:'武汉',city:2,home:3,job:6,studentWork:'none',commute:0,rel:0,risk:0,time:0,kidCount:0,incomeNum:2000,rent:0,leisure:400,opening:2000});
}

test('储蓄杠杆卡片与点击后的预览使用同一自然储蓄预测和整数百分点',async()=>{
 assert.deepEqual(simulationComparison(.896,.904),{before:90,after:90,delta:0});
 const cases=[
  [student(5000,6),0,0,0],
  [student(6000,12),32,98,66],
  [student(12000,24),0,5,5]
 ];
 for(const [s,before,after,delta] of cases){
  const data=view(s),base=coachScenario(data),h=controller(s);
  for(const impact of base.result.sens){
   const preview=coachScenario(data,{kind:impact.kind});
   assert.deepEqual(impact.natural,preview.result.natural);
   assert.equal(impact.delta,impact.after-impact.before);
  }
  await h.driver.act('coach-outcome');
  h.driver.render();
  const saveCard=h.mount.innerHTML.split('每月尝试多存 ¥500</b>')[1]?.split('</div>')[0];
  assert.ok(saveCard?.includes(`<strong>${before}% → ${after}%</strong>`));
  assert.ok(saveCard.includes(`>+${delta} 个百分点</span><small>自然可存 ¥350 → ¥470/月`));
  await h.driver.act('lever',{dataset:{kind:'save',label:'每月尝试多存 ¥500'}});
  h.driver.render();
  assert.ok(h.mount.innerHTML.includes(`原始条件 ${before}% → 调整后 ${after}%（+${delta} 个百分点）`));
  assert.deepEqual(h.state,s);
 }
});

test('路演账单建议仍能将均衡方案由每月370元调整至420元',()=>{
 const s=change(change(student(6000,12),'coach_route',{index:1}),'sample_bill');
 const period=month(),op=analyzeBills(s,period).opportunities.find(x=>x.id==='late-takeout');
 const preview=billPlanPreview(view(s),period,op.id,op.suggestedCents);
 assert.equal(preview.beforeRouteSaveCents,37000);
 assert.equal(preview.afterRouteSaveCents,42000);
 const after=change(s,'bill_plan',{period,opportunity:op.id,reduction:op.suggestedCents/100,monthlyConfirmed:true});
 assert.equal(after.coachRoute.monthlyCents,42000);
 assert.equal(summary(after).cashCents,summary(s).cashCents);
});

test('未核实的两种说法进入待核对，已有流水可关联，模拟来源需主动选择',async()=>{
 let s=change(initial(),'profile',{opening:1000,income:2000,expense:1000});
 const rows=[
  {date:day(),time:'12:00:00',merchant:'小王',desc:'垫付',amount:'100',direction:'out',externalId:'advance'},
  {date:day(),time:'13:00:00',merchant:'小王',desc:'归还',amount:'40',direction:'in',externalId:'part'}
 ];
 s=change(s,'import',{source:'wechat',rows});
 s=change(s,'link_loan',{id:s.transactions[0].id,name:'小王',kind:'垫付'});
 const h=controller(s),id=s.cases[0].id,cash=summary(s).cashCents;
 await h.driver.act('due-status',{dataset:{id}});
 for(const message of ['小王说他已经还清了，但我没看到入账','对方说已经还了100元，我这边还没有核实']){
  await h.driver.chat(message);
  h.driver.render();
  assert.match(h.mount.innerHTML,/<h2>还款待核对<\/h2>/);
  assert.match(h.mount.innerHTML,/查找对应的入账流水/);
  assert.doesNotMatch(h.mount.innerHTML,/data-form="repay"/);
  assert.equal(h.driver.dump().pending,null);
  assert.equal(summary(h.state).cashCents,cash);
  assert.equal(summary(h.state).receivableCents,10000);
 }
 assert.equal(h.calls.filter(x=>x.path==='prepare'&&x.args.type==='repay').length,0);
 await h.driver.act('repay',{dataset:{id,linkedOnly:'1',partial:'1'}});
 h.driver.render();
 assert.match(h.mount.innerHTML,/<select name="transactionId" required>/);
 assert.doesNotMatch(h.mount.innerHTML,/生成模拟还款记录/);
 const transactionId=s.transactions[1].id;
 await h.driver.prepare('repay',{id,amount:'40',transactionId});
 await h.driver.commitPending();
 assert.equal(summary(h.state).receivableCents,6000);
 assert.equal(summary(h.state).cashCents,cash);
 assert.equal(h.state.transactions.length,2);

 await h.driver.act('due-status',{dataset:{id}});
 await h.driver.act('repay',{dataset:{id}});
 h.driver.render();
 assert.match(h.mount.innerHTML,/<option value="" selected>请选择已核实的流水/);
 assert.match(h.mount.innerHTML,/<option value="__simulate__" >仅沙箱体验：生成模拟还款记录/);
 await h.driver.prepare('repay',{id,amount:'60'});
 assert.equal(h.driver.dump().pending.type,'repay');
 await h.driver.chat('他表示余额已经还清，但我没在账单里看到入账');
 assert.equal(h.driver.dump().pending,null);
 assert.equal(h.calls.filter(x=>x.path==='cancel').length,1);
 assert.equal(summary(h.state).receivableCents,6000);
 assert.equal(summary(h.state).cashCents,cash);
});
