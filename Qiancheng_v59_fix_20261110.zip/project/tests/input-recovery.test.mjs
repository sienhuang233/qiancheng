import test from 'node:test';
import assert from 'node:assert/strict';
import {apply,initial,month,summary} from '../lib/domain.mjs';
import {plan} from '../lib/agent.mjs';
import {controller} from './helpers/controller.mjs';
import {SUBSCRIPTION_REQUEST} from '../public/engines/subscriptions.mjs';

const fragments=['东京地下','zksk额计算机','我上课睡觉我','我看我哭死','tod上课','sd宿舍','实际就是就是','觉得见到你'];
const funded=()=>apply(initial(),'profile',{opening:'1000',income:'2000',expense:'1000'}).state;

test('截图里的误发和不完整句子不被填成姓名，补发明确姓名后接回原付款',async()=>{
 const h=controller(funded());
 await h.driver.chat('转账');
 await h.driver.chat('100元');
 const saved=h.driver.dump().agentContext;
 assert.equal(saved.stage,'name');
 assert.equal(saved.draft.amount,'100');
 for(const message of [...fragments,'手滑发错了','AAA']){
  await h.driver.chat(message);
  assert.deepEqual(h.driver.dump().agentContext,saved,message);
  assert.equal(h.driver.dump().pending,null,message);
  assert.match(h.driver.dump().messages.at(-1).text,/核对对方姓名/,message);
 }
 assert.equal(h.calls.filter(c=>c.path==='prepare').length,0);
 await h.driver.chat('对方叫东京地下');
 assert.equal(h.driver.dump().pending.args.name,'东京地下');
 assert.equal(h.driver.dump().pending.args.amount,'100');
 assert.equal(h.state.transactions.length,0);
});

test('只把独立金额或明确付款指令填入金额，不截取跑题文本中的数字',async()=>{
 const h=controller(funded());
 await h.driver.chat('帮我转给小王');
 const saved=h.driver.dump().agentContext,cash=summary(h.state).cashCents;
 assert.equal(saved.stage,'amount');
 for(const message of ['听课听到123','食堂午饭20元','asdf200元','发错了']){
  await h.driver.chat(message);
  assert.deepEqual(h.driver.dump().agentContext,saved,message);
  assert.equal(h.driver.dump().pending,null,message);
 }
 await h.driver.chat('给小王转100然后去上课2222');
 assert.equal(h.driver.dump().pending,null);
 assert.equal(h.driver.dump().agentContext.draft.amount??'','');
 await h.driver.chat('发错了，改成200元');
 assert.equal(h.driver.dump().pending.args.name,'小王');
 assert.equal(h.driver.dump().pending.args.amount,'200');
 assert.equal(summary(h.state).cashCents,cash);
});

test('储蓄和订阅核对接到跑题消息时保留当前任务',async()=>{
 const s=initial(),first=await plan(s,'我想攒5000元');
 const miss=await plan(s,'上课签到200元，第6个月',first.context,null,[],{page:'goal'});
 assert.equal(miss.proposal,null);
 assert.deepEqual(miss.context,first.context);
 assert.match(miss.reply,/多久攒到/);
 const next=await plan(s,'6个月',miss.context,null,[],{page:'goal'});
 assert.equal(next.proposal.args.target,'5000');
 assert.equal(next.proposal.args.months,6);

 const billed=apply(s,'sample_bill',{}).state,billPeriod=month();
 const entered=await plan(billed,SUBSCRIPTION_REQUEST,{},null,[],{billPeriod,taskChannel:'subscription-start'});
 const decision=await plan(billed,'腾讯视频不用',entered.context,null,[],{billPeriod});
 assert.equal(decision.context.subscriptionFlow.byPeriod[billPeriod].stage,'decision');
 const unrelated=await plan(billed,'东京地下',decision.context,null,[],{billPeriod});
 assert.equal(unrelated.proposal,null);
 assert.deepEqual(unrelated.context,decision.context);
 assert.match(unrelated.reply,/核对订阅|预览模拟取消/);
});

test('未识别输入不会仅凭模型分类跳到生活资料、账单或余额',async()=>{
 const fetcher=globalThis.fetch,key=process.env.BIGMODEL_API_KEY,model=process.env.BIGMODEL_MODEL;
 try{
  process.env.BIGMODEL_API_KEY='test-only';process.env.BIGMODEL_MODEL='test-only';
  let calls=0,intent='profile';
  globalThis.fetch=async()=>{calls++;return {ok:true,json:async()=>({choices:[{message:{content:JSON.stringify({intent})}}]})};};
  const s=initial();
  for(const message of ['sd宿舍','tod上课','zksk额计算机']){
   const r=await plan(s,message);
   assert.equal(r.inputRecovery,true);
   assert.equal(r.proposal,null);
   assert.equal(r.interview,undefined);
  }
  assert.equal(calls,0);
  for(intent of ['profile','analyze','balance','subscription_inspect']){
   const r=await plan(s,'东京地下');
   assert.equal(r.proposal,null);
   assert.equal(r.task,undefined);
   assert.equal(r.interview,undefined);
   assert.match(r.reply,/没接上/);
  }
 }finally{
  globalThis.fetch=fetcher;
  for(const [name,value] of [['BIGMODEL_API_KEY',key],['BIGMODEL_MODEL',model]]){
   if(value===undefined)delete process.env[name];else process.env[name]=value;
  }
 }
});
