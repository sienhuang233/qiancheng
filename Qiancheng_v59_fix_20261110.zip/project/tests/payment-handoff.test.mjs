import test from 'node:test';
import assert from 'node:assert/strict';
import {apply,day,initial,summary} from '../lib/domain.mjs';
import {paymentHandoffResponse} from '../lib/payment-handoff.mjs';
import {controller} from './helpers/controller.mjs';

const change=(s,type,args)=>apply(structuredClone(s),type,args).state;
const funded=()=>change(initial(),'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});
const click=(h,action,value)=>h.driver.act('payment-handoff-choice',{dataset:{id:h.driver.dump().agentContext.paymentHandoff.token,choice:action,value}});

test('收款人否定撤下旧确认，选择同名联系人后重新核对原金额与备注',async()=>{
 let s=funded();
 s=change(s,'contact',{name:'小李',phone:'13800001234',note:'同学'});
 s=change(s,'contact',{name:'小李',phone:'13800005678',note:'室友'});
 const h=controller(s),cash=summary(s).cashCents;
 await h.driver.chat('转给小王500元，用途是房租');
 const old=h.driver.dump().pending;
 await h.driver.chat('不是给小王，刚才发错了');
 assert.equal(h.driver.dump().pending,null);
 assert.equal(h.driver.dump().agentContext.paymentHandoff.draft.name,'');
 await assert.rejects(()=>h.api('commit',{id:old.id,confirm:true}));
 h.driver.render();
 assert.doesNotMatch(h.mount.innerHTML,/data-form="commit"/);
 assert.match(h.mount.innerHTML,/更换收款人/);
 assert.match(h.mount.innerHTML,/取消这笔付款/);
 await click(h,'change');
 await h.driver.chat('改成给小李');
 assert.equal(h.driver.dump().pending,null);
 h.driver.render();
 assert.match(h.mount.innerHTML,/尾号 1234/);
 assert.match(h.mount.innerHTML,/尾号 5678/);
 const selected=h.state.contacts.find(c=>c.phone.endsWith('5678'));
 await click(h,'contact',selected.id);
 const fresh=h.driver.dump().pending;
 assert.notEqual(fresh.id,old.id);
 assert.equal(fresh.args.contactId,selected.id);
 assert.equal(fresh.args.amount,'500');
 assert.equal(fresh.args.purpose,'房租');
 assert.equal(summary(h.state).cashCents,cash);
 h.driver.render();
 assert.match(h.mount.innerHTML,/收款人：小李（联系方式尾号 5678 · 室友）/);
 await h.driver.commitPending();
 assert.equal(h.state.transactions.at(-1).merchant,'小李');
 assert.equal(summary(h.state).cashCents,cash-50000);
});

test('插问本月消费后保留原付款，裸金额仅作为候选，接回和执行分两步',async()=>{
 const s=change(funded(),'transfer',{name:'食堂',amount:'12',kind:'普通付款'});
 const h=controller(s),cash=summary(s).cashCents;
 await h.driver.chat('转给小王');
 assert.equal(h.driver.dump().agentContext.stage,'amount');
 await h.driver.chat('我这个月花了多少');
 assert.match(h.driver.dump().messages.at(-1).text,/已确认消费 ¥12.00/);
 assert.match(h.driver.dump().messages.at(-1).text,/给小王的付款草稿还在等金额/);
 assert.equal(h.driver.dump().peoplePanel,null);
 await h.driver.chat('200元');
 assert.equal(h.driver.dump().pending,null);
 assert.equal(h.driver.dump().agentContext.paymentHandoff.draft.amount,'');
 h.driver.render();
 assert.match(h.mount.innerHTML,/继续给小王付款 · ¥200.00/);
 await h.driver.chat('确认');
 assert.equal(h.driver.dump().pending,null);
 await click(h,'amount');
 assert.equal(Number(h.driver.dump().pending.args.amount),200);
 assert.equal(h.driver.dump().pending.args.name,'小王');
 assert.equal(summary(h.state).cashCents,cash);
 await h.driver.commitPending();
 assert.equal(summary(h.state).cashCents,cash-20000);
});

test('发错和放弃分开；过期草稿不能由旧按钮接回',()=>{
 const s=funded(),pendingTransfer={id:'old',args:{name:'小王',amount:'100',kind:'普通付款'}};
 const opened=paymentHandoffResponse(s,'算了，发错了',{pendingTransfer,revision:1,now:1000});
 assert.equal(opened.invalidatedPendingId,'old');
 assert.equal(opened.context.paymentHandoff.stage,'choice');
 const cancelled=paymentHandoffResponse(s,'这笔不付了',{persisted:opened.context,revision:1,now:1001});
 assert.equal(cancelled.context.paymentHandoff,undefined);
 assert.equal(cancelled.proposal,null);
 const expired=paymentHandoffResponse(s,'更换收款人',{persisted:opened.context,revision:1,now:301000,selected:{action:'change',token:opened.context.paymentHandoff.token}});
 assert.match(expired.reply,/已过期/);
 assert.equal(expired.proposal,null);
});

test('换人同时否定金额与备注时，只用重新补充的字段生成确认',()=>{
 const s=funded(),pendingTransfer={id:'old',args:{name:'小王',amount:'500',purpose:'房租',kind:'普通付款'}};
 const opened=paymentHandoffResponse(s,'不是给小王，金额也不对，备注也错了',{pendingTransfer,revision:1,now:1000});
 assert.equal(opened.context.paymentHandoff.draft.amount,'');
 assert.equal(opened.context.paymentHandoff.draft.purpose,'');
 const named=paymentHandoffResponse(s,'改成给小李',{persisted:opened.context,revision:1,now:1001});
 assert.equal(named.proposal,null);
 const ready=paymentHandoffResponse(s,'300元',{persisted:named.context,revision:1,now:1002});
 assert.equal(ready.proposal.args.name,'小李');
 assert.equal(Number(ready.proposal.args.amount),300);
 assert.equal(ready.proposal.args.purpose,'');
});

test('本月消费口径排除重复、未来和未核对记录',()=>{
 const s=funded(),date=day();
 const row={kind:'expense',cents:1200,direction:'out',date,cat:'food'};
 s.transactions.push({...row,id:'valid'},{...row,id:'dup',duplicateOf:'valid'},{...row,id:'future',date:'9999-12-31'},{...row,id:'unknown',kind:'unknown'});
 const r=paymentHandoffResponse(s,'本月花了多少钱',{context:{intent:'payment_interview',stage:'amount',draft:{kind:'普通付款',name:'小王',amount:''}},revision:1});
 assert.match(r.reply,/已确认消费 ¥12.00/);
 assert.equal(r.proposal,null);
});
