// 数字溯源：页面上带虚线的数字都能点开，看到它到底从哪来。
// 四类来源分开列：① 你的流水 ② 你填/说过的条件 ③ 程序假设 ④ 留空＝待核实。
// 这里只做"解释"，不参与任何计算，也不改任何状态。
//
// 移植自 v59 决赛修订（1.9.62）的同一模块，按我们这版引擎逐条核对过数值：
// 2000 条路径、职业波动 5%–35%、收入中断 1%–12%、弹性超支 12%、通胀 3%、
// 偶发开销 6% 概率 150–700、大额每年 12% 概率 2000–10000、投资收益按 0 计。
// 与那份包的两处不同：① 不写死行号（行号会漂，改成函数名引用）；
// ② 补上原表漏掉的一条——模拟里每月有 8% 概率只存到一半（slip）。
import {coachScenario} from './engines/coach-scenario.mjs';
import {executionPlan} from './engines/plan.mjs';
import {analyzeBills} from './engines/bill-analysis.mjs';
import {CAT_NAME} from './engines/classifier.mjs';
import {DATA_SRC} from './engines/goal.mjs';

const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>n==null?'待补充':'¥'+(n/100).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
const yuan=n=>n==null?'待补充':'¥'+Math.round(n).toLocaleString('zh-CN');
const pct=p=>p==null?'—':(Math.round(p*1000)/10)+'%';
const catName=c=>CAT_NAME[c]||c;

/* ---------- 程序假设清单：每一条都标"是代码事实还是未校准估计" ---------- */
const A={
  paths:{title:'模拟路径数量',value:'2000 条',note:'固定随机种子，同样输入得到同样结果，不会每次刷新都变。',src:'goal.mjs · simulate() 的 N',kind:'fact'},
  vol:{title:'收入波动',value:'按职业 5%–35%/年',note:'科技 18%、金融 15%、制造 10%、餐饮零售 20%、体制内 5%、自由职业 35%、在校 6%。另按职业每年 2%–10% 收入增长（在校不计）。',src:'goal.mjs · BASE.job',kind:'assumption'},
  layoff:{title:'收入中断',value:'在校 2%，各职业 1%–12%/年',note:'自由职业最高（12%），体制内最低（1%）。中断期间按原收入 55% 计。',src:'goal.mjs · LAYOFF 与 simulate()',kind:'assumption'},
  band:{title:'支出带',value:'弹性支出 ×0.85 到 ×1.25',note:'刚性支出（房租、家庭责任）不打折；弹性支出（餐饮、交通、日用）按区间抽样。',src:'goal.mjs · derive() 的 lo / hi',kind:'assumption'},
  slip:{title:'弹性超支',value:'12%',note:'日常支出按 12% 计提超支，房租、学费、赡养费不参与。',src:'goal.mjs · FLEX_SLIP',kind:'assumption'},
  slipMonth:{title:'当月只存一半',value:'每月 8% 概率',note:'少数月份储蓄只完成一半，用来模拟"这个月实在挤不出来"。原版说明里没写这条，这里补上。',src:'goal.mjs · simulate() 的 slipRoll',kind:'assumption'},
  infl:{title:'支出通胀',value:'3%/年',note:'房租与物价按年上调，折算到月。',src:'goal.mjs · INFL',kind:'assumption'},
  shock:{title:'偶发开销',value:'每月 6% 概率，150–700 元',note:'学生档 50–200 元。',src:'goal.mjs · simulate() 的 shock',kind:'assumption'},
  large:{title:'大额支出',value:'每年 12% 概率，2000–10000 元',note:'学生档 200–1000 元。发生在单独某个月，不是在第 0 个月一次性扣掉。',src:'goal.mjs · simulate() 的 large',kind:'assumption'},
  returns:{title:'投资收益',value:'0',note:'全部按现金积累计算，不假设理财收益。',src:'goal.mjs · simulate() 的 bal 累加',kind:'fact'},
  rent:{title:'默认房租',value:'城市档位 × 住房系数',note:'城市 1000–2600 元 × 合租 1.0 / 整租 1.8 / 与家人 0.35 / 宿舍 0.2。留空才使用。',src:'goal.mjs · BASE.city / BASE.home',kind:'assumption'},
  food:{title:'餐饮与日用',value:'按城市档位',note:'餐饮 820–1300 元，日用 350 元；学生档餐饮 900、日用 150。',src:'goal.mjs · FOOD / DAILY',kind:'assumption'},
  leisure:{title:'非必要消费',value:'按城市档位 550–900 元',note:'社交、娱乐、购物；可在表单里改成你自己的数。',src:'goal.mjs · LEISURE',kind:'assumption'}
};
export const ASSUMPTIONS=Object.entries(A).map(([id,x])=>({id,...x}));

/* ---------- 可点击数字 ---------- */
export function prov(key,inner,label=''){
  return `<span class="prov" role="button" tabindex="0" data-prov="${esc(key)}" title="查看这个数字从哪里来${label?'：'+esc(label):''}">${inner}</span>`;
}
export function isKnownProvKey(key){
  return /^(?:metric:(?:cash|expense|receivable|available)|goal:(?:prob|save|natural)|goal:plan:[0-2]:(?:prob|save)|bill:(?:total|protected|pending)|bill:cat:[a-z]+|plan:(?:monthly|weekly|daily|living))$/.test(String(key||''));
}

/* ---------- 版块与行 ---------- */
const sec=(n,title,body)=>`<section class="prov-sec"><h3><i>${n}</i>${title}</h3>${body}</section>`;
const row=(k,v,note='')=>`<div class="prov-row"><span>${esc(k)}${note?`<small>${esc(note)}</small>`:''}</span><b>${v}</b></div>`;
const none=t=>`<p class="prov-empty">${esc(t)}</p>`;
const tag=t=>`<span class="prov-tag">${esc(t)}</span>`;
function assumeList(ids){
  return ids.map(id=>{const x=A[id];if(!x)return '';const k=x.kind==='fact'?'代码事实':'未校准估计';
    return `<div class="prov-assume"><div class="prov-assume-head"><b>${esc(x.title)}</b><span>${esc(x.value)}</span>${tag(k)}</div><small>${esc(x.note)}</small><small class="prov-src">来源：${esc(x.src)}</small></div>`;}).join('');
}
const periodOf=(st,sum)=>st.lastBillPeriod||sum.period||new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'}).slice(0,7);

/* ---------- 各数字的解释 ---------- */
function metric(st,sum,sub){
  const live=st.transactions.filter(t=>!t.duplicateOf&&!t.excluded);
  if(sub==='cash'){
    const ins=live.filter(t=>t.direction==='in').reduce((v,t)=>v+t.cents,0);
    const outs=live.filter(t=>t.direction==='out').reduce((v,t)=>v+t.cents,0);
    const excluded=st.transactions.length-live.length;
    return {title:'账户现金',now:money(sum.cashCents),html:
      sec('①','你的数据',row('期初现金',money(st.openingCents),'来自「资金起点」表单')+row('所有入账合计','+ '+money(ins))+row('所有出账合计','− '+money(outs))+row('未计入的被排除记录',excluded+' 笔','疑似重复或你勾选排除的')+`<p class="prov-note">现金＝期初 + 全部已计入流水。借出、还款本金也在这里加减，所以它不等于"本月消费"。</p>`)+
      sec('②','你的输入',row('期初现金是否已知',st.openingKnown?'是':'未知','未知时现金显示"—"'))+
      sec('③','程序假设',none('这一项不含任何估计参数：只做加减。'))+
      sec('④','待核实',st.openingKnown?none('没有留空项。'):row('期初现金','未知','未知时现金为"—"，可用资金同样未知'))};
  }
  if(sub==='expense'){
    const p=periodOf(st,sum);
    const rows=live.filter(t=>t.date.startsWith(p)&&t.kind==='expense');
    const cats=Object.entries(rows.reduce((a,t)=>(a[t.cat]=(a[t.cat]||0)+t.cents,a),{})).sort((a,b)=>b[1]-a[1]).slice(0,5);
    return {title:'本月已确认消费',now:money(sum.expenseCents),html:
      sec('①','你的数据',(rows.length?rows.slice(0,6).map(t=>row(t.merchant,money(t.cents),t.date)).join(''):none('这个月还没有已确认消费。'))+`<p class="prov-note">共 ${rows.length} 笔，${esc(p)} 期间的已确认消费（只列前 6 笔）。</p>`)+
      sec('②','你的输入',cats.length?cats.map(([c,v])=>row('分类：'+catName(c),money(v))).join(''):none('没有可归类的消费。'))+
      sec('③','程序假设',`<p class="prov-note">口径：借出（loan_out）、借入（borrow_in）、还款本金（repayment）、中性流水都不算消费；疑似重复和你排除的记录不计入。</p>`)+
      sec('④','待核实',sum.pendingCents?row('用途待确认的流水',money(sum.pendingCents),'未计入上面的消费'):none('没有待确认流水。'))};
  }
  if(sub==='receivable'){
    const list=st.cases.filter(c=>c.kind!=='借入'&&Math.max(0,Math.round(c.amount*100)-Math.round(c.paid*100)-Math.round(c.offset*100))>0);
    return {title:'待收回',now:money(sum.receivableCents),html:
      sec('①','你的数据',list.length?list.map(c=>row(c.recipient,money(Math.max(0,Math.round(c.amount*100)-Math.round(c.paid*100)-Math.round(c.offset*100))),c.kind+(c.dueDate?' · 约 '+c.dueDate:''))).join(''):none('当前没有人欠你钱（或都已结清）。'))+
      sec('②','你的输入',row('每笔往来由你确认的对象与金额','见人情往来','AA 只记对方份额'))+
      sec('③','程序假设',none('这一项不含估计：逐笔相加。'))+
      sec('④','待核实',`<p class="prov-note">"对方说还了"但你没核实的，仍算待收；只有关联到真实入账或确认还款才会减少。</p>`)};
  }
  if(sub==='available'){
    const cash=sum.cashCents;
    return {title:'可用资金',now:money(sum.availableCents),html:
      sec('①','你的数据',row('账户现金',money(cash))+row('目标预留','− '+money(sum.reservedCents))+row('应急金','− '+money(st.profile.emergencyCents||0))+row('待还款','− '+money(sum.payableCents))+`<p class="prov-note">可用＝现金 − 预留 − 应急金 − 待还；结果最低为 0，待收不计入。</p>`)+
      sec('②','你的输入',row('应急金',money(st.profile.emergencyCents||0),'在「资金起点」里填'))+
      sec('③','程序假设',none('纯减法，没有估计参数。'))+
      sec('④','待核实',cash==null?row('期初现金','未知','未知时可用资金也未知'):none('没有留空项。'))};
  }
  return null;
}

function goalNum(st,sum,sub){
  const sc=coachScenario({state:st,summary:sum});
  if(!sc)return {title:'储蓄方案',now:null,html:sec('①','你的数据',none('还没有足够条件：需要一个目标、生活条件和现金起点。'))+sec('②','你的输入',none(''))+sec('③','程序假设',none(''))+sec('④','待核实',none(''))};
  const r=sc.result,band=r.band,params=sc.params;
  const m=sub.match(/^plan:([0-2]):(prob|save)$/);
  const plan=m?r.plans[Number(m[1])]:null;
  const value=m?(m[2]==='prob'?pct(plan.prob):money(Math.round(plan.save*100))):sub==='prob'?pct(r.natural.sim.prob):sub==='save'||sub==='natural'?money(Math.round(r.natural.save*100)):null;
  const title=m?plan.name+'方案 · '+(m[2]==='prob'?'达标比例':'每月预设储蓄'):sub==='prob'?'自然储蓄的达标比例':'自然可存金额';
  const sim=r.natural.sim;
  const inputs=[
    row('目标',money(st.goal?.targetCents),'来自你说的目标或「确认目标」表单'),
    row('期限',(st.goal?.months||'—')+' 个月',''),
    row('月收入或生活费',yuan(band.income),'你填写的收入，不按职业猜'),
    row('房租',yuan(band.rent),st.coach?.rent==null?'留空 → 使用演示档位':'你填写的'),
    row('家庭/关系支出',yuan(band.family),''),
    row('非必要消费',yuan(band.leisure),'')
  ].join('');
  const stats=m?`<p class="prov-note">这条路线每月预设存 ${money(Math.round(plan.save*100))}；2000 条路径里有 ${Math.round(plan.prob*2000)} 条在截止前达到过目标（${pct(plan.prob)}）。期末仍达标的比例 ${pct(plan.terminalProb)}。</p>`:
    `<p class="prov-note">2000 条路径里有 ${sim.hits} 条在截止前达到过目标（${pct(sim.prob)}）；期末仍达标的比例 ${pct(sim.terminalProb)}，期末资金中位数 ${money(Math.round(sim.p50*100))}。</p>`;
  return {title,now:value,html:
    sec('①','你的数据',row('可用于目标的起点',money(Math.round(params.saved*100)),'可用资金 + 已为本目标预留')+row('已有预留',money(sum.savedCents))+`<p class="prov-note">待收的钱不计入起点；模拟里也不假设投资收益。</p>`)+
    sec('②','你的输入',inputs)+
    sec('③','程序假设',assumeList(r.plans&&r.plans.length?['paths','vol','layoff','band','slip','slipMonth','infl','shock','large','returns']:['paths']))+
    sec('④','待核实',`<p class="prov-note">所有参数都是量级估计，未经目标人群校准；这个比例描述"在假设下有多少条路径达标"，不是你个人的真实成功概率。${DATA_SRC.ret?.ref?'':'数据源的引用位置目前留空，显示为待核实。'}</p>`)+stats};
}

function billNum(st,sum,sub){
  const p=periodOf(st,sum),rep=analyzeBills(st,p);
  const live=st.transactions.filter(t=>!t.excluded&&!t.duplicateOf&&t.date.startsWith(p));
  if(sub==='total'){
    return {title:'本期已确认消费',now:money(rep.totalCents),html:
      sec('①','你的数据',(rep.categories.length?rep.categories.slice(0,6).map(c=>row(catName(c.cat),money(c.cents),Math.round(c.share*100)+'%')).join(''):none('本期还没有消费记录。'))+`<p class="prov-note">共 ${rep.expenseCount} 笔消费，来自 ${live.length} 笔已核对流水中的支出。</p>`)+
      sec('②','你的输入',row('分析月份',p,'来自页面上的月份选择')+row('被排除的记录',rep.excludedCount+' 笔','疑似重复或你勾选排除'))+
      sec('③','程序假设',`<p class="prov-note">分类来自词典命中与原始分类先验；两类分数接近时判为"待确认"，不硬猜。</p>`)+
      sec('④','待核实',rep.pendingCents?row('用途待确认',money(rep.pendingCents),'未计入上面的消费'):none('没有待确认流水。'))};
  }
  if(sub==='protected'){
    return {title:'亲友与必要责任',now:money(rep.protectedCents),html:
      sec('①','你的数据',`<p class="prov-note">被识别为亲友往来或必要责任（赡养、礼物、生日、父母、医疗、学费、房租、借款、还款、垫付等）的支出合计。</p>`)+
      sec('②','你的输入',none('这一项不读你的表单，只读流水文字与分类。'))+
      sec('③','程序假设',`<p class="prov-note">按商户名与商品说明里的关键词识别；可能漏判或误判，不作道德判断。</p>`)+
      sec('④','待核实',none('具体明细见账单表格，可逐笔改口径。'))};
  }
  if(sub==='pending'){
    const rows=live.filter(t=>t.kind==='unknown'||t.kind==='unknown_in');
    return {title:'仍需核对性质',now:money(rep.pendingCents),html:
      sec('①','你的数据',rows.length?rows.slice(0,8).map(t=>row(t.merchant,money(t.cents),t.date)).join(''):none('没有待核对流水。'))+
      sec('②','你的输入',none('核对由你逐笔确认；确认后分类才会变。'))+
      sec('③','程序假设',none('这一项不含估计：只把"没说清用途"的流水单列。'))+
      sec('④','待核实',`<p class="prov-note">这些钱已经真实发生，但在你确认性质前，不当作日常消费、也不算浪费。</p>`) };
  }
  const cat=sub.slice(4),c=rep.categories.find(x=>x.cat===cat);
  return {title:'分类金额 · '+catName(cat),now:c?money(c.cents):'—',html:
    sec('①','你的数据',c?row('本期合计',money(c.cents))+row('占本期消费',Math.round(c.share*100)+'%')+`<p class="prov-note">该分类下共 ${live.filter(t=>t.cat===cat&&t.kind==='expense').length} 笔。</p>`:none('本期没有这个分类的记录。'))+
    sec('②','你的输入',row('分类来源','词典 + 你的确认','你勾选"记住"后会优先按你的设定'))+
    sec('③','程序假设',`<p class="prov-note">词典命中权重：商户 3 分、商品说明 2.4 分、备注 1.5 分；原始交易分类再给先验。</p>`)+
    sec('④','待核实',none('单笔明细可在账单表格里核对。'))};
}

/* 执行计划的四个数字 */
function planNum(st,sum,sub){
  const p=executionPlan({state:st,summary:sum});
  if(!p)return {title:'执行计划',now:null,html:sec('①','你的数据',none('还没有选定路线：先在目标教练里比较三条方案并确认一条。'))+sec('②','你的输入',none(''))+sec('③','程序假设',none(''))+sec('④','待核实',none(''))};
  const weeks=(52/12).toFixed(2);
  const map={
    monthly:{title:'每月目标储蓄',now:money(p.monthlySaveCents),body:row('按已选路线的月存额',money(p.monthlySaveCents),'来自你确认的那条方案')},
    weekly:{title:'每周日常支出额度',now:money(p.weeklyCents),body:row('可支配生活预算',money(p.livingCents))+row('减去目标储蓄',money(p.monthlySaveCents))+row('÷ '+weeks+' 周',money(p.weeklyCents),'周额度与日额度是同一笔钱的两个视角')},
    daily:{title:'每日参考额度',now:money(p.dailyCents),body:row('弹性支出（餐饮、交通、日用）',money(p.monthlyFlexibleCents))+row('÷ 30.4 天',money(p.dailyCents),'不是额外再给一份预算')},
    living:{title:'每月生活预算',now:money(p.livingCents),body:row('刚性支出（房租、家庭责任）',money(p.rigidCents),'不打折')+row('弹性支出（餐饮、交通、日用）',money(p.monthlyFlexibleCents),'是你的预算，不是模型估的')}
  }[sub];
  if(!map)return null;
  return {title:map.title,now:map.now,html:
    sec('①','你的数据',map.body+`<p class="prov-note">收入 ${money(p.incomeCents)}、月存 ${money(p.monthlySaveCents)}、余量 ${money(p.bufferCents)} 都来自你已确认的条件与路线。</p>`)+
    sec('②','你的输入',row('路线',p.chosen.name,'你确认采用的方案'))+
    sec('③','程序假设',assumeList(['band','leisure','infl']))+
    sec('④','待核实',`<p class="prov-note">周额度/日额度只是把同一笔月预算摊开，不能相加；超出预警阈值也不代表可以多花。</p>`)};
}

/* ---------- 抽屉入口 ---------- */
export function provenanceDrawer(data,key){
  try{
    const st=(data&&data.state)||{},sum=(data&&data.summary)||{};
    let body=null;
    if(String(key).startsWith('metric:'))body=metric(st,sum,String(key).slice(7));
    else if(String(key).startsWith('goal:'))body=goalNum(st,sum,String(key).slice(5));
    else if(String(key).startsWith('bill:'))body=billNum(st,sum,String(key).slice(5));
    else if(String(key).startsWith('plan:'))body=planNum(st,sum,String(key).slice(5));
    if(!body)body={title:'这个数字暂未登记来源',now:null,html:sec('④','待核实',none('本版只覆盖现金、消费、待收、可用资金、达标比例、账单与执行计划里的主要数字。'))};
    return `<div class="prov-card"><div class="eyebrow">数字溯源 · 点开看它从哪来</div><h2>${esc(body.title)}</h2>${body.now!=null?`<p class="prov-now">当前显示 <b>${body.now}</b></p>`:''}${body.html}
      <p class="prov-foot">四类来源：① 你的流水 ② 你填/说过的条件 ③ 程序假设 ④ 留空＝待核实。${tag('代码事实')}表示这是程序行为，不是估计；${tag('未校准估计')}表示参数是量级参考，不能当个人预测。</p>
      <div class="stack"><button data-act="close">关闭</button></div></div>`;
  }catch(e){
    return `<div class="prov-card"><h2>这个数字的来源暂时取不到</h2><p class="prov-note">${esc(e.message)}</p><button data-act="close">关闭</button></div>`;
  }
}
