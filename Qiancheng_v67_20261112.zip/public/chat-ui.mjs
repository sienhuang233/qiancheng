import {quotedMessage} from './quote-ui.mjs';
import {PROFILE_CHOICES} from './engines/profile.mjs';
import {CITY_LIST} from './engines/cities.mjs';
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// 现实条件表单：放在气泡外，避免被 .bubble 的 pre-wrap 和内边距挤压。
// 提交时由 app.mjs 拼成一句话送进对话，所以这里不写任何计算——表单只是换个方式说话。
// values 会在重绘时回填，否则用户打字期间一次 render 就会清空已填内容。
export function profileTemplateMarkup(values={}){
 const v=k=>esc(values[k]??'');
 const sel=(rows,k)=>rows.map(([val,t])=>`<option value="${esc(val)}"${String(values[k])===String(val)?' selected':''}>${esc(t)}</option>`).join('');
 const kind=String(values.job)==='6'?'每月生活费':'每月收入';
 return `<div class="chat-card profile-template" data-card="profile"><div class="chat-card-head"><b>补充现实条件</b><span class="prov-tag">一次填完</span></div><p class="chat-card-desc">已经按常见情况填好，改掉不对的数字就行；不确定的项留空，之后还能补。</p><form data-form="profile-template" class="profile-grid"><label>城市<input name="place" list="qc-city-list" maxlength="20" placeholder="如 宁波 / 福建" value="${v('place')}" autocomplete="off"><datalist id="qc-city-list">${CITY_LIST.map(c=>`<option value="${esc(c)}"></option>`).join('')}</datalist></label><label>身份<select name="job"><option value="">请选择</option>${sel(PROFILE_CHOICES.job,'job')}</select></label><label>住房<select name="home"><option value="">请选择</option>${sel(PROFILE_CHOICES.home,'home')}</select></label><label>家庭阶段<select name="rel"><option value="">请选择</option>${sel(PROFILE_CHOICES.rel,'rel')}</select></label><label>${kind}（元）<input name="income" type="number" min="0" step="1" inputmode="numeric" value="${v('income')}"></label><label>每月房租（元）<input name="rent" type="number" min="0" step="1" inputmode="numeric" placeholder="不用交填 0" value="${v('rent')}"></label><label>已有存款（元）<input name="opening" type="number" min="0" step="1" inputmode="numeric" placeholder="没有填 0" value="${v('opening')}"></label><div class="chat-card-actions"><button class="primary" type="submit" data-act="profile-submit">填入并继续</button><button type="button" data-act="profile-step">改用逐句回答</button></div></form><p class="chat-card-note">提交后会把以上内容作为一句话发给你核对；只用于评估方案，不会改动账户和流水。</p></div>`;
}

// Display request status and the returned processing receipt, never invented reasoning.
export function chatMessages(messages,user={},flow=null,disabled=false,paymentHandoff=null){
 const userName=String(user.name||'我').slice(0,24);
 return messages.map((m,index)=>{if(!m.pending&&!m.text&&m.form!=='profile')return '';
  const outgoing=m.who==='user',name=outgoing?userName:'钱程';
  const receipt=m.status&&!outgoing&&!m.pending?`<details class="chat-receipt ${m.failed?'model-error':''}"><summary>${m.requestFailed?'请求未完成':m.failed?'本次使用规则兜底':m.mode==='ai'?'模型已回应':m.mode==='rules'?'规则处理':'处理说明'}</summary><p>${esc(m.status)}</p></details>`:'';
  const clarification=!outgoing&&!m.pending&&m.clarification?'<small class="clarification-status">待澄清 · 本轮未生成新草案</small>':'';
  const progress=flow?.byPeriod?.[flow.period],showControls=!outgoing&&!m.pending&&index===messages.length-1&&flow&&!flow.paused;
  const control=(label,choice,name='')=>`<button type="button" data-act="subscription-reply" data-choice="${choice}" data-period="${esc(flow.period)}" data-name="${esc(name)}" ${disabled?'disabled':''}>${esc(label)}</button>`;
  const controls=showControls?`<div class="subscription-controls">${progress?.stage==='usage'?control('仍在用','keep')+control('不再需要','stop')+control('稍后核对','later'):progress?.stage==='decision'?control('预览模拟取消','cancel-preview')+control('先保留','keep')+control('稍后核对','later'):progress?.stage==='done'?control('返回账单建议','back')+(progress.hasMore===false?'':control('再核对一项','more')):progress?.stage==='choose'?control('稍后核对','later'):''}</div>`:'';
  const paymentControls=!outgoing&&!m.pending&&index===messages.length-1&&paymentHandoff?.choices?.length?`<div class="subscription-controls">${paymentHandoff.choices.map(c=>`<button type="button" data-act="payment-handoff-choice" data-id="${esc(paymentHandoff.token)}" data-choice="${esc(c.action)}" data-value="${esc(c.value)}" ${disabled?'disabled':''}>${esc(c.label)}</button>`).join('')}</div>`:'';
  return `<article class="chat-message ${outgoing?'outgoing':'incoming'}" data-message-index="${index}"><div class="chat-avatar ${outgoing?'avatar-user':'avatar-agent'}" aria-hidden="true">${outgoing?'我':'钱'}</div><div class="message-body"><div class="message-heading"><span class="message-name">${esc(name)}</span>${!m.pending?`<button class="message-reply" data-act="quote-message" data-id="${index}" aria-label="引用${esc(name)}这条消息">↩</button>`:''}</div><div class="bubble ${outgoing?'user':''}">${quotedMessage(m.quote)}${clarification}${esc(m.text)}${m.pending?'<div class="chat-thinking" role="status"><span class="thinking-dots" aria-hidden="true"><i></i><i></i><i></i></span><span>正在理解你的需求…</span></div>':''}</div>${m.form==='profile'?profileTemplateMarkup(m.formValues||{}):''}${receipt}${controls}${paymentControls}</div></article>`;
 }).join('');
}
