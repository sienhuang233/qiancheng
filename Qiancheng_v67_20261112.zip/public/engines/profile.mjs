export function hasCompleteProfile(state){
 const c=state.coach;
 return !!c&&state.openingKnown===true&&['place','incomeNum','home','job','rent','rel'].every(k=>c[k]!==null&&c[k]!==undefined&&c[k]!=='');
}
export const PROFILE_FIELDS=['place','incomeNum','opening','home','job','rent','rel'];
export function missingProfile(state,draft={}){return PROFILE_FIELDS.filter(k=>(k!=='opening'||!state.openingKnown)&&(draft[k]==null||draft[k]===''));}
export const PROFILE_INTRO='为了评估目标是否可行，请补充你的城市、学生或工作身份、住房情况、每月收支、已有存款及家庭负担。';
export const PROFILE_EXAMPLES='也可以直接说“试试武汉在校生”或“试试深圳职场新人”，用模拟条件体验。';
export function profileCollection(missing,{offerExample=true}={}){
 const labels={place:'城市',job:'学生或工作身份',home:'住房情况',incomeNum:'每月收入或生活费',opening:'已有存款',rent:'每月房租（没有可说0）',rel:'家庭或关系阶段'};
 const message=missing.length===PROFILE_FIELDS.length?PROFILE_INTRO:'为了评估目标是否可行，还需补充你的'+missing.map(k=>labels[k]).join('、')+'。可以一次告诉我。';
 return message+(offerExample?PROFILE_EXAMPLES:'');
}
export function requestedPersona(message){
 const q=String(message||'').trim();
 if(/^(?:(?:我想|让我|请)?(?:选择|用|体验|试试|试一试|试一下|试用))武汉(?:在校生|在校大学生|大学生)(?:虚构体验|案例|情形)?[。！!\s]*$/.test(q))return 'student';
 if(/^(?:(?:我想|让我|请)?(?:选择|用|体验|试试|试一试|试一下|试用))深圳职场新人(?:虚构体验|案例|情形)?[。！!\s]*$/.test(q))return 'worker';
 return null;
}
export const canPreviewPersona=s=>s.demo||(!s.coach&&!s.openingKnown&&!s.transactions.length&&!s.cases.length&&!s.contacts.length);

// 第二步现实条件：把"还缺什么"拼成一句用户可以直接改、直接发的话。
// 已有字段用真实值，缺失字段用常见示例值，让用户只改数字而不是从零组织语言。
const JOB_PHRASE=['做互联网/科技','做金融/专业服务','做制造/工程','做餐饮零售/服务','在体制内工作','自由职业/创业','在校读书'];
const HOME_PHRASE=['和别人合租','自己整租','和父母同住','住学校宿舍'];
const REL_PHRASE=['单身','恋爱、暂无婚姻计划','恋爱、有婚姻计划','已婚'];
const DRAFT_SAMPLE={place:'深圳',incomeNum:'8000',rent:'1800',opening:'3000'};
export function profileDraftSentence(missing=[],draft={}){
  const has=k=>draft[k]!==null&&draft[k]!==undefined&&draft[k]!=='';
  const pick=(k,list)=>{const i=Number(draft[k]);return has(k)&&Number.isInteger(i)&&list[i]?list[i]:list[0]};
  const money=(k)=>{const v=has(k)?String(draft[k]):DRAFT_SAMPLE[k];return String(v).replace(/\.0+$/,'').replace(/\.00$/,'')};
  const student=has('job')&&Number(draft.job)===6;
  // 住宿舍或与家人同住通常没有房租，示例值给 0，避免草稿里塞一个不存在的支出
  const rentSample=has('home')&&[2,3].includes(Number(draft.home))?'0':DRAFT_SAMPLE.rent;
  const parts=[`我在${has('place')?draft.place:DRAFT_SAMPLE.place}`,pick('job',JOB_PHRASE),pick('home',HOME_PHRASE),
    `${student?'每月生活费':'月薪'} ${money('incomeNum')}`,'房租 '+(has('rent')?money('rent'):rentSample),pick('rel',REL_PHRASE)];
  if(missing.includes('opening')||has('opening'))parts.push('已有存款 '+money('opening'));
  return parts.join('，')+'。';
}

/* ---------- 现实条件表单（对话内一次填完） ----------
 * 选项值必须与上面 JOB_PHRASE / HOME_PHRASE / REL_PHRASE 的下标一一对应：
 * 表单提交后拼成一句话送进对话，服务端的正则再按同一套下标还原。
 * 值改了而语料没改，就会把"在校学生"识别成"做互联网"。
 */
export const PROFILE_CHOICES={
  job:[[6,'在校学生'],[0,'互联网/科技'],[1,'金融/专业服务'],[2,'制造/工程'],[3,'餐饮零售/服务'],[4,'体制内/教师/医护'],[5,'自由职业/创业']],
  home:[[0,'合租'],[1,'整租'],[2,'与家人同住'],[3,'学校宿舍']],
  rel:[[0,'单身'],[1,'恋爱 · 暂无婚姻计划'],[2,'恋爱 · 有婚姻计划'],[3,'已婚']]
};

// 表单初始值：已有真实值直接填，缺的用示例值占位，让用户只改数字。
// city 不下推到表单——表单填的是城市名，档位由服务端 cities.mjs 反查。
export function profileTemplateValues(draft={}){
  const has=k=>draft[k]!==null&&draft[k]!==undefined&&draft[k]!=='';
  const plain=k=>String(draft[k]).replace(/\.0+$/,'').replace(/\.00$/,'');
  const student=has('job')&&Number(draft.job)===6;
  const rent=has('home')&&[2,3].includes(Number(draft.home))?'0':DRAFT_SAMPLE.rent;
  return {
    place:has('place')?draft.place:DRAFT_SAMPLE.place,
    job:has('job')?String(draft.job):'',
    home:has('home')?String(draft.home):'',
    rel:has('rel')?String(draft.rel):'',
    income:has('incomeNum')?plain('incomeNum'):DRAFT_SAMPLE.incomeNum,
    rent:has('rent')?plain('rent'):rent,
    opening:has('opening')?plain('opening'):DRAFT_SAMPLE.opening,
    student
  };
}

// 表单值 → 一句话。只拼用户真填了的项，留空的交给服务端继续问。
export function profileTemplateSentence(v={}){
  const pick=(k,list)=>{const i=Number(v[k]);return v[k]!==''&&v[k]!=null&&Number.isInteger(i)&&list[i]?list[i]:''};
  const num=k=>{const x=v[k];return x==null||x===''?'':String(x).trim().replace(/\.0+$/,'').replace(/\.00$/,'')};
  const student=String(v.job)=== '6';
  const parts=[];
  const place=String(v.place??'').trim().slice(0,20);
  if(place)parts.push('我在'+place);
  const job=pick('job',JOB_PHRASE);if(job)parts.push(job);
  const home=pick('home',HOME_PHRASE);if(home)parts.push(home);
  const income=num('income');if(income)parts.push(`${student?'每月生活费':'月薪'} ${income}`);
  const rent=num('rent');if(rent)parts.push('房租 '+rent);
  const rel=pick('rel',REL_PHRASE);if(rel)parts.push(rel);
  const opening=num('opening');if(opening)parts.push('已有存款 '+opening);
  return parts.join('，');
}
