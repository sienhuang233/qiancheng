export const SUBSCRIPTION_REQUEST='帮我分析当前账单月份的订阅，并带我核对一项是否需要保留。';
export const validBillPeriod=p=>/^\d{4}-(?:0[1-9]|1[0-2])$/.test(String(p||''));
const services=[['腾讯视频','video'],['爱奇艺','video'],['QQ音乐','music'],['网易云音乐','music']];
// 解约入口是静态资料：只有用户本人在商户后台或支付渠道才能真的停扣。
// 这里只描述路径，不代登录、不发起任何请求。
const guides={
 '腾讯视频':{service:'腾讯视频 App → 我的 → 我的VIP会员 → 管理自动续费'},
 '爱奇艺':{service:'爱奇艺 App → 我的 → 我的VIP会员 → 管理自动续费'},
 'QQ音乐':{service:'QQ音乐 App → 我的 → 会员中心 → 管理自动续费'},
 '网易云音乐':{service:'网易云音乐 App → 账号 → 黑胶VIP → 管理自动续费'}
};
const CHANNEL='支付宝：我的 → 设置 → 支付设置 → 免密支付/自动扣款；微信：我 → 服务 → 钱包 → 支付设置 → 自动续费';
export function cancelGuide(row){
 const hit=guides[row?.name];
 return {
  name:row?.name||'该服务',
  service:hit?.service||`${row?.name||'该服务'} App → 我的 / 账户 → 会员与订阅 → 管理自动续费（各家叫法不同，找“自动续费 / 连续包月”）`,
  channel:CHANNEL,
  script:`我订阅的${row?.name||'该服务'}会员请帮我关闭自动续费，并停止后续扣款；本期内如已扣费且未使用，一并申请退款。`
 };
}
const DAY=86400000;
function addMonth(d){
 const [y,m,day]=d.toISOString().slice(0,10).split('-').map(Number);
 const last=new Date(Date.UTC(y,m+1,0)).getUTCDate();
 return new Date(Date.UTC(y,m,Math.min(day,last)));
}
// 只凭账单能算的"下次大概什么时候扣"：同一天扣的按月推同日，其余按间隔推，
// 单笔只有在账单写明连续包月/自动续费时才给日期。单笔普通消费一律不给。
export function nextCharge(row,today){
 const dates=(row?.history?.length?row.history:row?.dates||[]).filter(d=>/^\d{4}-\d\d-\d\d$/.test(d)).sort();
 if(!dates.length||!/^\d{4}-\d\d-\d\d$/.test(String(today||'')))return null;
 const base=new Date(dates.at(-1)+'T00:00:00Z'),now=new Date(today+'T00:00:00Z');
 const sameDay=dates.every(d=>d.slice(8)===dates[0].slice(8));
 let at=null,basis='',step=null;
 if(dates.length>=2){
  const gap=Math.round((base-new Date(dates[0]+'T00:00:00Z'))/DAY/(dates.length-1));
  if(gap>=28&&gap<=31&&sameDay){at=addMonth(base);basis=`按账单历史 ${dates.length} 笔都在每月${Number(dates[0].slice(8))}日扣费推算`;}
  else if(gap>=20&&gap<=400){step=gap;at=new Date(+base+gap*DAY);basis=`按账单历史 ${dates.length} 笔的间隔（约${gap}天）推算`;}
 }
 if(!at&&row?.recurringHint){at=addMonth(base);basis='按账单中的连续包月标记推算，具体日期以平台通知为准';}
 if(!at)return null;
 for(let i=0;i<13&&Math.round((at-now)/DAY)<0;i++)at=step?new Date(+at+step*DAY):addMonth(at);
 const days=Math.round((at-now)/DAY);
 if(days<0)return null;
 return {date:at.toISOString().slice(0,10),days,basis};
}
// 用户标记取消之后仍在扣的款：这是"解约到底生效没有"的唯一证据。
export function chargesAfterDecision(row){
 if(row?.status!=='cancelled'||!row.decidedAt)return [];
 const decided=String(row.decidedAt).slice(0,10);
 return row.dates.filter(d=>d>decided);
}
function subscriptionName(t){
 const content=[t.merchant,t.desc,t.rawType,t.rawCat].join(' '),known=services.find(([name])=>content.toLowerCase().includes(name.toLowerCase()));
 if(t.cat!=='subs'&&!/会员|订阅|包月|自动续费|连续扣费/.test(content)&&!(known&&/充值/.test(content)))return null;
 const name=known?.[0]||t.merchant;
 return name?{name,group:known?.[1]||'other',content}:null;
}
export function subscriptionEvidence(s,period){
 if(!validBillPeriod(period))throw Error('请选择有效的账单月份');
 const groups=new Map(),history=new Map();
 for(const t of s.transactions){
  if(t.excluded||t.duplicateOf||t.direction!=='out'||t.kind!=='expense')continue;
  const hit=subscriptionName(t);if(!hit)continue;
  // 历史扣费日跨月保留，用来推算下次扣费；本期金额与笔数仍只看所选月份。
  if(!history.has(hit.name))history.set(hit.name,[]);history.get(hit.name).push(t.date);
  if(!t.date.startsWith(period))continue;
  const saved=s.subscriptions.find(x=>x.name===hit.name);
  const row=groups.get(hit.name)||{name:hit.name,group:hit.group,cents:0,count:0,dates:[],transactionIds:[],recurringHint:false,status:saved?.status||'unreviewed',decidedAt:saved?.at||null};
  row.cents+=t.cents;row.count++;row.dates.push(t.date);row.transactionIds.push(t.id);row.recurringHint||=/连续包月|自动续费|连续扣费|代扣/.test(hit.content);groups.set(hit.name,row);
 }
 return [...groups.values()].map(x=>({...x,dates:[...new Set(x.dates)].sort(),history:[...new Set(history.get(x.name)||[])].sort()}));
}
export function isSubscriptionRequest(q){
 return /订阅|会员|连续扣费|续费|代扣|包月|退订|网易云|QQ音乐|爱奇艺|腾讯视频/.test(q);
}
export function isSubscriptionMainline(q){
 return /^钱程推荐(?:下一步)?[：:]/.test(q)||/返回(?:账单建议|预算建议|主线)/.test(q)||/返回(?:账单|预算|主线)|预算建议|预算调整|预览.*(?:调整|预算)|转账(?:的)?用途|转账核对|人情往来|(?:我想|我要|帮我|设置|设定|修改).*(?:攒|存钱|储蓄目标)|核对.*(?:转账|垫付|到账)|记录.*(?:人情|垫付)|(?:分析|导入)(?:这份|自己的|本月)?账单(?!.*订阅)/.test(q)&&!isSubscriptionRequest(q);
}
