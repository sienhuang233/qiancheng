import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,apply} from '../lib/domain.mjs';
import {sampleBillAllowed,billSourceTask} from '../public/engines/conversation.mjs';
import {billConversation} from '../lib/bill-agent.mjs';
import {billSourceDialog} from '../public/plan-ui.mjs';

const change=(s,t,a={})=>apply(structuredClone(s),t,a).state;
// 走完目标教练：目标 + 现实条件（确认期初现金 2000），这是演示时最常见的实际状态。
const withCoach=()=>{
  let s=change(initial(),'goal',{target:20000,months:12});
  s=change(s,'coach',{place:'武汉',city:2,home:3,job:6,studentWork:'none',commute:0,rel:0,risk:0,time:0,kidCount:0,incomeNum:2000,rent:0,leisure:400,opening:2000});
  return s;
};

test('做完目标教练的账户仍允许载入虚构账单',()=>{
  const s=withCoach();
  assert.equal(s.openingKnown,true,'前置：教练流程已确认期初现金');
  assert.equal(s.transactions.length,0);
  assert.equal(sampleBillAllowed(s),true,'openingKnown 不能成为拦截理由');
  assert.equal(billSourceTask(s).action,'load-sample-bill');
});

test('已确认期初现金的账户，服务端也真的能载入而且不覆盖起点',()=>{
  const s=withCoach();
  const out=apply(structuredClone(s),'sample_bill',{});
  assert.ok(out.state.transactions.length>0,'应载入样本流水');
  assert.equal(out.state.demo,true);
  assert.equal(out.state.openingCents,s.openingCents,'期初现金沿用已确认值，不重复算收入');
});

test('对话里说“用虚拟账单体验”能拿到载入任务，而不是被劝去导入自己的账单',()=>{
  const s=withCoach();
  const r=billConversation(s,'用虚构账单体验',{intent:'bill_source'});
  assert.ok(r,'不应落空');
  assert.equal(r.task?.action,'load-sample-bill');
  assert.doesNotMatch(r.reply,/不能混入|已有真实账单/);
});

test('真实账单、往来记录、联系人仍然拦住虚构账单',()=>{
  const real=change(initial(),'import',{source:'csv',rows:[{date:new Date().toISOString().slice(0,10),merchant:'某商户',desc:'消费',amount:12,direction:'out',kind:'expense'}]});
  assert.equal(sampleBillAllowed(real),false,'有真实流水应拦住');
  const blocked=billConversation(real,'用虚构账单体验',{intent:'bill_source'});
  assert.equal(blocked.task,undefined);
  assert.match(blocked.reply,/真实账单或往来记录/);
  assert.equal(sampleBillAllowed({...initial(),cases:[{id:'c1'}]}),false);
  assert.equal(sampleBillAllowed({...initial(),contacts:[{id:'p1'}]}),false);
});

test('已经载入过虚拟账单的账户不再拦截（改为分析已有结果）',()=>{
  const s=apply(structuredClone(withCoach()),'sample_bill',{}).state;
  assert.equal(sampleBillAllowed(s),true);
});

test('账单来源弹窗的按钮在教练流程后不再置灰',()=>{
  const html=billSourceDialog({state:withCoach()},'2026-11');
  assert.match(html,/选择虚拟账单体验/);
  assert.doesNotMatch(html,/data-act="sample-bill"[^>]*disabled/,'按钮不应带 disabled');
  assert.doesNotMatch(html,/已有真实账单或往来记录/,'可用时不该显示被拦的说明');
  const blocked=billSourceDialog({state:change(initial(),'import',{source:'csv',rows:[{date:new Date().toISOString().slice(0,10),merchant:'某商户',desc:'消费',amount:12,direction:'out',kind:'expense'}]})},'2026-11');
  assert.match(blocked,/data-act="sample-bill"[^>]*disabled/,'真实账户仍应禁用');
  assert.match(blocked,/已有真实账单或往来记录/);
});
