import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import http from 'node:http';
import {mkdtempSync,rmSync,writeFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve,join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
import {duplicatePairs,analyzeBills,MAX_DUPLICATE_PAIRS} from '../public/engines/bill-analysis.mjs';
import {initial,apply,summary,day} from '../lib/domain.mjs';
const period=day().slice(0,7);
function oldPairs(rows){const pairs=[];for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++){const a=rows[i],b=rows[j];if(a.date===b.date&&a.merchant===b.merchant&&a.cents===b.cents&&Math.abs(Date.parse(a.date+'T'+a.time)-Date.parse(b.date+'T'+b.time))<=3600000)pairs.push({firstId:a.id,secondId:b.id,merchant:a.merchant,cents:a.cents});}return pairs;}
test('v59同日同商户同额一小时窗口与原两两判断等价，未截断时顺序保持',()=>{let seed=13;const rand=n=>(seed=(Math.imul(seed,1664525)+1013904223)>>>0)%n;for(let k=0;k<150;k++){const rows=Array.from({length:30},(_,i)=>({id:'t'+i,date:period+'-'+String(1+rand(2)).padStart(2,'0'),time:String(rand(4)).padStart(2,'0')+':'+String(rand(60)).padStart(2,'0')+':00',merchant:'m'+rand(4),cents:100*(1+rand(2))}));const a=oldPairs(rows),b=duplicatePairs(rows);assert.deepEqual(b.pairs,a);assert.equal(b.pairCount,a.length);assert.equal(b.pairsTruncated,false);}});
test('v59精确一小时边界与无效时间保持原判断',()=>{const rows=['12:00:00','13:00:00','13:00:01','invalid'].map((time,i)=>({id:'b'+i,date:day(),time,merchant:'x',cents:1}));assert.deepEqual(duplicatePairs(rows).pairs,oldPairs(rows));});
test('v59已排除和已标记重复流水不参加消费与新重复匹配',()=>{const tx=Array.from({length:4},(_,i)=>({id:'t'+i,date:day(),time:'12:00:00',merchant:'x',desc:'x',cents:1000,kind:'expense',direction:'out',cat:'other',...(i===2?{excluded:true}:i===3?{duplicateOf:'t0'}:{})}));const r=analyzeBills({...initial(),transactions:tx},period);assert.equal(r.totalCents,2000);assert.equal(r.pairCount,1);assert.equal(r.excludedCount,2);});
test('v5910000笔最坏同额重复报告只保存200条线索，仍精确计数所有匹配',()=>{const s={...initial(),transactions:Array.from({length:10000},(_,i)=>({id:'t'+i,date:day(),time:'12:00:00',merchant:'同一商户',desc:'资源核验',cents:1000,kind:'expense',direction:'out',cat:'other'}))};const started=performance.now(),r=analyzeBills(s,period),bytes=Buffer.byteLength(JSON.stringify(r));assert.equal(r.pairs.length,MAX_DUPLICATE_PAIRS);assert.equal(r.pairCount,49995000);assert.equal(r.pairsTruncated,true);assert.equal(r.totalCents,10000000);assert.ok(bytes<100000);assert.equal(s.transactions.length,10000);console.info('v59_duplicate_benchmark',JSON.stringify({rows:10000,pairCount:r.pairCount,storedPairs:r.pairs.length,bytes,elapsedMs:performance.now()-started}));});
test('v59纯模拟账本仍正常联动现金、待收与部分还款',()=>{let s=apply(initial(),'profile',{opening:'2000',income:'2000',expense:'1000',emergency:'0'}).state;s.demo=true;s=apply(s,'transfer',{name:'小王',amount:'100',kind:'垫付',dueType:'none'}).state;assert.equal(summary(s).cashCents,190000);s=apply(s,'repay',{id:s.cases[0].id,amount:'40'}).state;assert.equal(summary(s).cashCents,194000);assert.equal(summary(s).receivableCents,6000);});
let child,base,modelServer,modelCalls=0,a,subAccount;
const dir=mkdtempSync(join(tmpdir(),'qc-v59-'));
async function start(model=false){child=spawn(process.execPath,['server.mjs','--port','0'],{cwd:resolve(import.meta.dirname,'..'),env:{...process.env,DATA_DIR:dir,BIGMODEL_API_KEY:model?'mock-only':'',BIGMODEL_MODEL:model?'mock':'',AI_BASE_URL:model?'http://127.0.0.1:'+modelServer.address().port:'',PUBLIC_ORIGIN:'',COOKIE_SECURE:'0'},stdio:['ignore','pipe','pipe']});base=await new Promise((r,j)=>{child.stdout.on('data',b=>{const m=String(b).match(/localhost:(\d+)/);if(m)r('http://127.0.0.1:'+m[1]);});child.once('error',j);});}
async function stop(){await new Promise(r=>{child.once('exit',r);child.kill();});}
async function api(a,path,args,expected=200,scope=a?.data?.workspace.active){const r=await fetch(base+'/api/'+path,{method:args===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(a?{cookie:a.cookie,'X-CSRF-Token':a.data?.csrf||'','X-QC-Workspace':scope||'original'}:{})},body:args===undefined?undefined:JSON.stringify(args)}),j=await r.json();assert.equal(r.status,expected,JSON.stringify(j));return {data:j,response:r};}
async function load(a){return a.data=(await api(a,'state')).data;}
async function guest(){const r=await api(null,'guest',{});const a={cookie:r.response.headers.get('set-cookie').split(';')[0]};await load(a);return a;}
async function save(a,type,args){const p=(await api(a,'prepare',{type,args})).data,r=await api(a,'commit',{id:p.id,confirm:true});await load(a);return r.data;}
function quota(a,user=0,global=0){const db=new DatabaseSync(join(dir,'qiancheng.sqlite'));for(const [k,n]of [['ai:'+day()+':'+a.data.user.id,user],['ai-global:'+day(),global]])db.prepare('INSERT INTO limits VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=excluded.n,expires=excluded.expires').run(k,n,Date.now()+86400000);db.close();}
function used(a){const db=new DatabaseSync(join(dir,'qiancheng.sqlite'));const row=db.prepare('SELECT n FROM limits WHERE k=?').get('ai:'+day()+':'+a.data.user.id);db.close();return row?.n||0;}
before(async()=>{modelServer=http.createServer(async(req,res)=>{for await(const b of req){}modelCalls++;res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({choices:[{message:{content:JSON.stringify({intent:'other',answer:'请核对当前页面。'})}}]}));});await new Promise(r=>modelServer.listen(0,'127.0.0.1',r));await start();a=await guest();});
after(()=>{child?.kill();modelServer?.close();rmSync(dir,{recursive:true,force:true});});
const row=(id,amount='10',direction='out')=>({date:day(),time:'12:00:00',merchant:direction==='in'?'小王':'食堂',desc:direction==='in'?'归还':'午餐',amount,direction,externalId:id});
let real,sim,realBefore;
test('v59规则对话不消耗模型日额度，原40次额度耗尽仍能续接',async()=>{quota(a,40,500);const r=(await api(a,'chat',{message:'5000元六个月',context:{intent:'goal_details'}})).data;assert.equal(r.mode,'rules');assert.equal(r.proposal.args.target,'5000');assert.equal(used(a),40);assert.equal((await load(a)).state.goal,null);});
test('v59真实账单的模拟付款预览和取消不切换数据域，不修改原记录',async()=>{await save(a,'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});await save(a,'import',{rows:[row('real1')],source:'wechat'});real=a.data.workspace.active;realBefore=structuredClone(a.data.state);const p=(await api(a,'prepare',{type:'transfer',args:{name:'小王',amount:'100',kind:'垫付',dueType:'none'}})).data;assert.equal(p.isolated,true);assert.equal((await load(a)).workspace.active,real);assert.deepEqual(a.data.state,realBefore);await api(a,'cancel',{id:p.id});assert.deepEqual((await load(a)).state,realBefore);});
test('v59确认模拟付款后只更新隔离模拟账本，重复确认只执行一次',async()=>{const id=a.data.user.id,p=(await api(a,'prepare',{type:'transfer',args:{name:'小王',amount:'100',kind:'垫付',dueType:'none'}})).data;const result=await Promise.all([api(a,'commit',{id:p.id,confirm:true}),api(a,'commit',{id:p.id,confirm:true},200,real)]);assert.equal(result.filter(x=>x.data.replayed).length,1);await load(a);sim=a.data.workspace.active;assert.notEqual(sim,real);assert.equal(a.data.user.id,id);assert.equal(a.data.summary.cashCents,89000);assert.equal(a.data.summary.receivableCents,10000);assert.equal(a.data.workspace.hasSimulation,true);assert.equal(a.data.state.transactions.filter(t=>t.importKey).length,1);});
test('v59返回真实域完整恢复原结果和聊天来源，模拟结果仍可找回',async()=>{await api(a,'bill-workspace',{scope:real,revision:a.data.revision});await load(a);assert.deepEqual(a.data.state,realBefore);assert.equal(a.data.summary.cashCents,99000);assert.equal(a.data.summary.receivableCents,0);await api(a,'bill-workspace',{scope:sim,revision:a.data.revision});await load(a);assert.equal(a.data.summary.cashCents,89000);});
test('v59模拟域部分还款继续在本域联动，不生成另一个身份或账本',async()=>{const scope=a.data.workspace.active;await save(a,'repay',{id:a.data.state.cases[0].id,amount:'40'});assert.equal(a.data.workspace.active,scope);assert.equal(a.data.summary.cashCents,93000);assert.equal(a.data.summary.receivableCents,6000);});
test('v59跨数据域不会重置同账号每日1000元风险阈值，游客红色草案仍保留待确认政策',async()=>{await api(a,'bill-workspace',{scope:real,revision:a.data.revision});await load(a);const before=structuredClone(a.data.state),p=(await api(a,'prepare',{type:'transfer',args:{name:'小王',amount:'901',kind:'普通付款'}})).data;assert.equal(p.risk,'red');const r=await api(a,'commit',{id:p.id,confirm:true},400);assert.match(r.data.error,/免注册会话尚无法完成密码复核绑定/);assert.deepEqual((await load(a)).state,before);assert.equal(a.data.workspace.active,real);await api(a,'cancel',{id:p.id});});
test('v59真实已到账流水关联还款不重复增加现金，也不切换模拟域',async()=>{await save(a,'import',{source:'wechat',rows:[{...row('real-loan','100'),merchant:'小王',rawType:'转账',desc:'垫付'},row('real-repay','40','in')]});const out=a.data.state.transactions.find(t=>t.externalId==='real-loan'),inc=a.data.state.transactions.find(t=>t.externalId==='real-repay');await save(a,'link_loan',{id:out.id,name:'小王',amount:'100',kind:'垫付',dueType:'none'});const before=a.data.summary.cashCents,scope=a.data.workspace.active;await save(a,'repay',{id:a.data.state.cases[0].id,amount:'40',transactionId:inc.id});assert.equal(a.data.summary.cashCents,before);assert.equal(a.data.workspace.active,scope);assert.equal(a.data.summary.receivableCents,6000);});
test('v59从真实往来生成模拟还款只影响模拟域，真实未结清金额保留',async()=>{const original=structuredClone(a.data.state),scope=a.data.workspace.active;await save(a,'repay',{id:a.data.state.cases[0].id,amount:'60'});assert.notEqual(a.data.workspace.active,scope);assert.equal(a.data.summary.receivableCents,0);assert.equal(a.data.summary.cashCents,original.openingCents-1000-10000+4000+6000);await api(a,'bill-workspace',{scope,revision:a.data.revision});assert.deepEqual((await load(a)).state,original);});
test('v59模拟副本中再导入同一真实账单复用原真实域和去重结果',async()=>{const p=(await api(a,'prepare',{type:'transfer',args:{name:'小王',amount:'10',kind:'普通付款'}})).data;await api(a,'commit',{id:p.id,confirm:true});await load(a);assert.notEqual(a.data.workspace.active,real);const r=await save(a,'import',{source:'wechat',rows:[row('real1')]});assert.equal(r.result.added,0);assert.equal(r.result.skipped,1);assert.equal(a.data.workspace.active,real);});
test('v59配置模型时日额度耗尽仍可规则补槽，不调用上游、不自动保存',async()=>{await stop();await start(true);quota(a,40,500);const calls=modelCalls,r=(await api(a,'chat',{message:'5000元六个月',context:{intent:'goal_details'}})).data;assert.equal(r.mode,'rules-fallback');assert.match(r.modelStatus,/额度已用完/);assert.equal(r.proposal.args.target,'5000');assert.equal(modelCalls,calls);assert.equal((await load(a)).state.goal,null);});
test('v59全局模型额度耗尽不会额外扣账户额度',async()=>{quota(a,0,500);const calls=modelCalls,r=(await api(a,'chat',{message:'六个月',context:{intent:'goal_details',target:'5000'}})).data;assert.equal(r.mode,'rules-fallback');assert.equal(modelCalls,calls);assert.equal(used(a),0);});
test('v59额度只在实际模型请求前扣一次，第40次可调用，第41次规则继续',async()=>{quota(a,39,0);const calls=modelCalls;let r=(await api(a,'chat',{message:'5000元六个月',context:{intent:'goal_details'}})).data;assert.equal(r.mode,'ai');assert.equal(modelCalls,calls+1);assert.equal(used(a),40);r=(await api(a,'chat',{message:'改成6000元',context:{intent:'goal_details',target:'5000',months:6}})).data;assert.equal(r.mode,'rules-fallback');assert.equal(r.proposal.args.target,'6000');assert.equal(modelCalls,calls+1);});
test('v59必须依赖模型才能理解时明确暂不可用并保留草稿上下文',async()=>{quota(a,40,500);const context={resumeTask:{action:'agent-transfer',transactionId:'unresolved'},draft:{recipient:'小王',amount:'100'}};const r=(await api(a,'chat',{message:'喵喵绕口令暂不能识别',context})).data;assert.equal(r.mode,'rules-fallback');assert.match(r.reply,/暂超出现有规则/);assert.deepEqual(r.context,context);assert.equal(r.proposal,null);});
test('v59模型额度耗尽时仍保留基础请求限流，不删除保护',async()=>{const db=new DatabaseSync(join(dir,'qiancheng.sqlite'));db.prepare('INSERT INTO limits VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET n=excluded.n,expires=excluded.expires').run('user:'+a.data.user.id,120,Date.now()+60000);db.close();await api(a,'chat',{message:'继续'},429);});
test('v59订阅分析在模型额度耗尽时继续规则核对，取消仍需原确认',async()=>{subAccount=await guest();await save(subAccount,'sample_bill',{});quota(subAccount,40,500);const calls=modelCalls,r=(await api(subAccount,'chat',{message:'帮我分析当前账单月份的订阅，并带我核对一项是否需要保留。',context:{},view:{page:'bills',billPeriod:period,taskChannel:'subscription-start'}})).data;assert.equal(r.mode,'rules-fallback');assert.match(r.modelStatus,/额度已用完/);assert.equal(modelCalls,calls);const stop=(await api(subAccount,'chat',{message:'不用，帮我关闭这个订阅',context:r.context,view:{page:'bills',billPeriod:period}})).data;assert.equal(stop.proposal.type,'subscription');const p=(await api(subAccount,'prepare',stop.proposal)).data;await api(subAccount,'commit',{id:p.id,confirm:false},400);await load(subAccount);assert.notEqual(subAccount.data.state.subscriptions.find(x=>x.name===p.summaryArgs.name).status,'cancelled');const before=subAccount.data.summary.cashCents,result=(await api(subAccount,'commit',{id:p.id,confirm:true})).data;assert.match(result.result.message,/已记录.*模拟取消/);assert.match(result.result.message,/停扣要在原平台操作/);await load(subAccount);assert.equal(subAccount.data.summary.cashCents,before);assert.match(subAccount.data.conversation.at(-1).text,/模拟取消/);});

test('决赛修订 HTTP：未核实的还款先核对，不调用模型；确认关联40元不重复入账',async()=>{
 const account=await guest();
 quota(account);
 await save(account,'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});
 await save(account,'import',{source:'wechat',rows:[
  {...row('finals-advance','100'),merchant:'小王',rawType:'转账',desc:'垫付'},
  row('finals-partial','40','in')
 ]});
 const [advance,incoming]=account.data.state.transactions;
 await save(account,'link_loan',{id:advance.id,name:'小王',amount:'100',kind:'垫付'});
 const id=account.data.state.cases[0].id,cash=account.data.summary.cashCents,calls=modelCalls;
 const messages=[
  ['小王说他已经还清了，但我没看到入账',{}],
  ['对方说已经还了100元，我这边还没有核实',{intent:'due_status',caseId:id}]
 ];
 for(const [message,context] of messages){
  const {data:result}=await api(account,'chat',{message,context});
  assert.equal(result.mode,'rules');
  assert.equal(result.proposal,null);
  assert.deepEqual(result.task,{action:'due-verify',caseId:id});
  assert.match(result.reply,/待核对/);
  await save(account,'due_check',{id,status:'verify'});
  assert.equal(account.data.summary.receivableCents,10000);
  assert.equal(account.data.summary.cashCents,cash);
  assert.equal(account.data.state.transactions.length,2);
 }
 assert.equal(modelCalls,calls);
 await save(account,'repay',{id,amount:'40',transactionId:incoming.id});
 assert.equal(account.data.summary.receivableCents,6000);
 assert.equal(account.data.summary.cashCents,cash);
 assert.equal(account.data.state.transactions.length,2);
});

test('决赛修订 HTTP：待澄清可恢复，明确金额后仅草案，口头确认不记账',async()=>{
 const account=await guest();
 quota(account);
 await save(account,'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});
 const cash=account.data.summary.cashCents,calls=modelCalls;
 const ambiguous=(await api(account,'chat',{message:'转给小王100元或200元'})).data;
 assert.equal(ambiguous.clarification,true);
 assert.equal(ambiguous.proposal,null);
 await load(account);
 assert.equal(account.data.conversation.at(-1).clarification,true);
 assert.equal(account.data.conversationContext.draft.name,'小王');
 assert.equal(account.data.conversationContext.draft.amount,'');
 assert.equal(modelCalls,calls);
 assert.equal(account.data.summary.cashCents,cash);

 const clarified=(await api(account,'chat',{message:'200元'})).data;
 assert.equal(clarified.proposal.args.name,'小王');
 assert.equal(clarified.proposal.args.amount,'200');
 const draft=(await api(account,'prepare',clarified.proposal)).data;
 const mistake=(await api(account,'chat',{message:'asdf计算机'})).data;
 assert.match(mistake.reply,/原草案还在等待核对/);
 assert.equal(mistake.proposal,null);
 assert.equal((await load(account)).summary.cashCents,cash);
 const acknowledgement=(await api(account,'chat',{message:'确认'})).data;
 assert.match(acknowledgement.reply,/页面核对后点击确认/);
 assert.equal(acknowledgement.proposal,null);
 assert.equal((await load(account)).summary.cashCents,cash);
 assert.equal(account.data.state.transactions.length,0);
 await api(account,'commit',{id:draft.id,confirm:true});
 await load(account);
 assert.equal(account.data.summary.cashCents,cash-20000);
 assert.equal(account.data.state.transactions.length,1);
});

test('付款 HTTP：撤销旧确认后无法提交，重复取消也不会丢掉待修改草稿',async()=>{
 const account=await guest();
 quota(account);
 await save(account,'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});
 const cash=account.data.summary.cashCents;
 const original=(await api(account,'prepare',{type:'transfer',args:{name:'小王',amount:'500',kind:'普通付款',purpose:'房租'}})).data;
 const corrected=(await api(account,'chat',{message:'不是给小王，刚才发错了',pendingId:original.id})).data;
 assert.equal(corrected.invalidatedPendingId,original.id);
 assert.equal(corrected.proposal,null);
 assert.equal(corrected.context.paymentHandoff.draft.name,'');
 await api(account,'commit',{id:original.id,confirm:true},400);
 await api(account,'cancel',{id:original.id});
 await load(account);
 assert.equal(account.data.conversationContext.paymentHandoff.stage,'choice');
 assert.equal(account.data.summary.cashCents,cash);
 const replacement=(await api(account,'chat',{message:'改成给小李'})).data;
 assert.equal(replacement.proposal.args.name,'小李');
 assert.equal(replacement.proposal.args.amount,'500');
 assert.equal(replacement.proposal.args.purpose,'房租');
 const fresh=(await api(account,'prepare',replacement.proposal)).data;
 assert.notEqual(fresh.id,original.id);
 await api(account,'commit',{id:original.id,confirm:true},400);
 await api(account,'commit',{id:fresh.id,confirm:true});
 await load(account);
 assert.equal(account.data.summary.cashCents,cash-50000);
 assert.deepEqual(account.data.state.transactions.map(t=>t.merchant),['小李']);
});

test('付款 HTTP：插问后裸金额与过时按钮不能提交，当前按钮只生成草案',async()=>{
 const account=await guest();
 quota(account);
 await save(account,'profile',{opening:'1000',income:'2000',expense:'1000',emergency:'0'});
 await save(account,'transfer',{name:'食堂',amount:'12',kind:'普通付款'});
 const cash=account.data.summary.cashCents;
 const draft=(await api(account,'chat',{message:'转给小王'})).data;
 assert.equal(draft.context.stage,'amount');
 const answer=(await api(account,'chat',{message:'我这个月花了多少'})).data;
 assert.match(answer.reply,/已确认消费 ¥12.00/);
 assert.match(answer.reply,/给小王的付款草稿还在等金额/);
 const first=(await api(account,'chat',{message:'100元'})).data;
 const second=(await api(account,'chat',{message:'200元'})).data;
 assert.equal(first.proposal,null);
 assert.equal(second.proposal,null);
 assert.equal(second.context.paymentHandoff.draft.amount,'');
 const choose=(token)=>api(account,'chat',{message:'继续付款',paymentChoice:{token,action:'amount'}});
 const stale=(await choose(first.context.paymentHandoff.token)).data;
 assert.equal(stale.proposal,null);
 assert.match(stale.reply,/选项已失效/);
 const valid=(await choose(second.context.paymentHandoff.token)).data;
 assert.equal(valid.proposal.args.name,'小王');
 assert.equal(Number(valid.proposal.args.amount),200);
 assert.equal((await load(account)).summary.cashCents,cash);
 const reused=(await choose(second.context.paymentHandoff.token)).data;
 assert.equal(reused.proposal,null);
 assert.equal(account.data.state.transactions.length,1);
});
