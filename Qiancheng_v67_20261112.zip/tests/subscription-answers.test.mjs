import test from 'node:test';
import assert from 'node:assert/strict';
import {apply, initial, month} from '../lib/domain.mjs';
import {plan} from '../lib/agent.mjs';

// 规则模式下的订阅核对：这些说法必须被接住，不能落到"这句我没接上"。
delete process.env.BIGMODEL_API_KEY;
delete process.env.BIGMODEL_MODEL;

const period = month();
const billed = apply(initial(), 'sample_bill', {}).state;

async function entered() {
  const r = await plan(billed, '看看订阅', {}, null, [], {billPeriod: period});
  const p = r.context.subscriptionFlow.byPeriod[period];
  assert.equal(p.stage, 'usage', '订阅入口应停在询问使用情况');
  return {context: r.context, current: p.current};
}

const ask = (context, message) => plan(billed, message, context, null, [], {billPeriod: period});
const progress = r => r.context.subscriptionFlow.byPeriod[period];

test('截图里的「不再需要」不再落到兜底，直接对当前项给出取消草案', async () => {
  const {context, current} = await entered();
  for (const message of ['不再需要', '不需要了', '不需要']) {
    const r = await ask(context, message);
    assert.notEqual(r.inputRecovery, true, `"${message}" 不该被当成跑题`);
    assert.doesNotMatch(r.reply, /没接上/, `"${message}" 不该兜底`);
    assert.equal(r.proposal?.args?.name, current, `"${message}" 应指向当前核对项`);
    assert.equal(r.proposal?.args?.status, 'cancelled');
    assert.equal(progress(r).stage, 'confirm');
  }
});

test('「不要了 / 不想用了 / 不再用了 / 以后不用了」都进决策追问，而不是重复问同一句', async () => {
  const {context, current} = await entered();
  for (const message of ['不要了', '不想用了', '不再用了', '没用了', '用不上了', '以后不用了', '不用了']) {
    const r = await ask(context, message);
    assert.notEqual(r.inputRecovery, true, `"${message}" 不该被当成跑题`);
    assert.equal(r.proposal, null, `"${message}" 只是说明不用了，不该直接出草案`);
    assert.equal(progress(r).stage, 'decision', `"${message}" 应停在预览取消/保留的追问`);
    assert.equal(progress(r).current, current);
    assert.match(r.reply, /预览模拟取消|保留/, `"${message}" 应给出两个处理方向`);
  }
});

test('「以后不用了」是停用决定，不能被当成稍后再说的暂停', async () => {
  const {context} = await entered();
  const r = await ask(context, '以后不用了');
  assert.notEqual(r.context.subscriptionFlow.paused, true, '说了不用了，不该把流程挂起');
  const paused = await ask(context, '以后再说');
  assert.equal(paused.context.subscriptionFlow.paused, true, '「以后再说」仍应保留进度');
  const later = await ask(context, '稍后再核对');
  assert.equal(later.context.subscriptionFlow.paused, true, '「稍后再核对」仍应保留进度');
});

test('决策阶段说「取消」指当前这一项，不是退出核对流程', async () => {
  const {context, current} = await entered();
  const decision = await ask(context, '不用了');
  assert.equal(progress(decision).stage, 'decision');
  for (const message of ['取消', '预览模拟取消']) {
    const r = await ask(decision.context, message);
    assert.equal(r.proposal?.args?.name, current, `"${message}" 应落在当前项`);
    assert.equal(r.proposal?.args?.status, 'cancelled');
    assert.notEqual(r.context.subscriptionFlow.paused, true, `"${message}" 不该把流程挂起`);
    assert.doesNotMatch(r.reply, /你指的是哪一项/, `"${message}" 已在核对当前项，不该再问哪一项`);
  }
  const kept = await ask(decision.context, '先保留');
  assert.equal(kept.proposal?.args?.status, 'keep');
});

test('明确说不要取消时，不生成草案', async () => {
  const {context} = await entered();
  for (const message of ['不用取消', '别取消', '先不取消', '不需要帮我取消']) {
    const r = await ask(context, message);
    assert.equal(r.proposal, null, `"${message}" 是保留的意思，不该出取消草案`);
    assert.match(r.reply, /尚未取消/, `"${message}" 应确认没有取消`);
  }
});

test('草案已备好后再说一次取消，仍指向当前项，不改口成“哪一项”', async () => {
  const {context, current} = await entered();
  const draft = await ask(context, '不再需要');
  assert.equal(progress(draft).stage, 'confirm');
  for (const message of ['预览模拟取消', '取消', '以后不用了']) {
    const r = await ask(draft.context, message);
    assert.doesNotMatch(r.reply, /你指的是哪一项|没接上/, `"${message}" 不该反问哪一项或兜底`);
    assert.equal(r.proposal?.args?.name, current);
    assert.equal(r.proposal?.args?.status, 'cancelled');
  }
  const kept = await ask(draft.context, '还在用');
  assert.equal(kept.proposal?.args?.status, 'keep');
});

test('跑题内容仍然兜底，闸门没有被放宽成什么都接', async () => {
  const {context} = await entered();
  for (const message of ['东京地下', 'sd宿舍', '我上课睡觉']) {
    const r = await ask(context, message);
    assert.equal(r.inputRecovery, true, `"${message}" 与订阅无关，仍应兜底`);
    assert.match(r.reply, /没接上/);
    assert.equal(r.proposal, null);
  }
});
