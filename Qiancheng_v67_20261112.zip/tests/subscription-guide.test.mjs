import test from 'node:test';
import assert from 'node:assert/strict';
import {apply, initial} from '../lib/domain.mjs';
import {nextCharge, cancelGuide, chargesAfterDecision, subscriptionEvidence} from '../public/engines/subscriptions.mjs';
import {billSuggestions} from '../public/bill-ui.mjs';

// 解约路径卡与扣费日提醒：只给路径和日期，绝不宣称代用户停扣。

const tx = (date, merchant, desc, cents) => ({
  id: `${merchant}-${date}`, date, time: '08:00:00', merchant, desc,
  cents, direction: 'out', kind: 'expense', cat: 'subs', simulated: true
});

const row = (dates, extra = {}) => ({name: '网易云音乐', dates, history: dates, recurringHint: false, cents: 1500, count: dates.length, ...extra});

test('跨月同日扣费：按月推同一天，不按 30 天漂移', () => {
  const n = nextCharge(row(['2026-09-05', '2026-10-05']), '2026-10-20');
  assert.equal(n.date, '2026-11-05');
  assert.equal(n.days, 16);
  assert.match(n.basis, /每月5日/);
});

test('非整月周期按实际间隔推算', () => {
  const n = nextCharge(row(['2026-06-10', '2026-09-10']), '2026-09-20');
  assert.equal(n.date, '2026-12-11');
  assert.match(n.basis, /间隔/);
});

test('单笔普通消费不给扣费日：账单不能证明自动续费', () => {
  assert.equal(nextCharge(row(['2026-10-05']), '2026-10-20'), null);
});

test('单笔但账单写明连续包月，仍按月推同一天并标注依据', () => {
  const n = nextCharge(row(['2026-10-05'], {recurringHint: true}), '2026-10-20');
  assert.equal(n.date, '2026-11-05');
  assert.match(n.basis, /连续包月/);
});

test('推算日已经过去时滚到下一个周期，不返回过去的日期', () => {
  const n = nextCharge(row(['2026-08-05', '2026-09-05']), '2026-11-12');
  assert.equal(n.date, '2026-12-05');
  assert.ok(n.days > 0);
});

test('本期账单里只有一笔时，仍能用历史扣费日推算', () => {
  const state = initial();
  state.transactions.push(
    tx('2026-09-05', '网易云音乐', '黑胶VIP连续包月', 1500),
    tx('2026-10-05', '网易云音乐', '黑胶VIP连续包月', 1500)
  );
  const [entry] = subscriptionEvidence(state, '2026-10');
  assert.deepEqual(entry.dates, ['2026-10-05'], '本期笔数只看所选月份');
  assert.deepEqual(entry.history, ['2026-09-05', '2026-10-05'], '历史扣费日跨月保留');
  assert.equal(nextCharge(entry, '2026-10-20').date, '2026-11-05');
});

test('解约入口：已知服务给到具体菜单，未知服务给通用路径', () => {
  const known = cancelGuide({name: '网易云音乐'});
  assert.match(known.service, /网易云音乐 App.*管理自动续费/);
  assert.match(known.channel, /免密支付|自动续费/);
  assert.match(known.script, /关闭自动续费|停止后续扣款/);
  const other = cancelGuide({name: '某个小众会员'});
  assert.match(other.service, /某个小众会员 App/);
  assert.match(other.service, /自动续费/);
});

test('取消后落库下次扣费日，文案直接给解约入口且不说已停扣', () => {
  const state = initial();
  state.transactions.push(
    tx('2026-09-05', '网易云音乐', '黑胶VIP连续包月', 1500),
    tx('2026-10-05', '网易云音乐', '黑胶VIP连续包月', 1500)
  );
  const {state: saved, result} = apply(state, 'subscription', {name: '网易云音乐', status: 'cancelled', period: '2026-10'});
  const record = saved.subscriptions.find(x => x.name === '网易云音乐');
  assert.equal(record.status, 'cancelled');
  assert.match(record.nextChargeAt, /^\d{4}-\d\d-\d\d$/);
  assert.match(result.message, /停扣要在原平台操作/);
  assert.match(result.message, /网易云音乐 App/);
  assert.doesNotMatch(result.message, /已为你取消|已完成解约/);
});

test('标记取消之后又扣款：账单页明确提示解约可能没生效', () => {
  const state = {
    transactions: [tx('2026-11-05', '网易云音乐', '黑胶VIP连续包月', 1500)],
    subscriptions: [{id: 's1', name: '网易云音乐', status: 'cancelled', at: '2026-10-28T10:00:00.000Z'}]
  };
  const html = billSuggestions({state}, '2026-11', {opportunities: []});
  assert.match(html, /missed-cancel/);
  assert.match(html, /标记取消之后仍有 1 笔扣费/);
});

test('决定发生在扣费之后时不误报：同月先扣款后取消不算解约失效', () => {
  const state = {
    transactions: [tx('2026-11-05', '网易云音乐', '黑胶VIP连续包月', 1500)],
    subscriptions: [{id: 's1', name: '网易云音乐', status: 'cancelled', at: '2026-11-06T02:00:00.000Z'}]
  };
  assert.deepEqual(chargesAfterDecision({status: 'cancelled', decidedAt: '2026-11-06T02:00:00.000Z', dates: ['2026-11-05']}), []);
  const html = billSuggestions({state}, '2026-11', {opportunities: []});
  assert.doesNotMatch(html, /missed-cancel/);
});

test('最近一笔扣费直接露在卡片上，不用展开面板', () => {
  const state = {transactions: [tx('2026-11-05', '网易云音乐', '黑胶VIP连续包月', 1500)], subscriptions: []};
  const html = billSuggestions({state}, '2026-11', {opportunities: []});
  assert.match(html, /next-charge/);
  assert.match(html, /最近一笔：<b>网易云音乐<\/b>/);
  assert.match(html, /解约入口（真正能停扣的地方）/);
});

test('一笔普通会员消费、没有连续包月标记：不编造扣费日', () => {
  const state = {transactions: [tx('2026-11-05', '某视频会员', '月度会员', 2500)], subscriptions: []};
  const html = billSuggestions({state}, '2026-11', {opportunities: []});
  assert.doesNotMatch(html, /next-charge/);
  assert.doesNotMatch(html, /下次预计/);
  assert.match(html, /只有一笔普通消费，无法判断是否自动续费/);
});
