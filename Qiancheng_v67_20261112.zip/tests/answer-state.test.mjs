import test from 'node:test';
import assert from 'node:assert/strict';
import {initial,apply,demoState} from '../lib/domain.mjs';
import {plan} from '../lib/agent.mjs';
import {controller} from './helpers/controller.mjs';

const change=(s,t,a={})=>apply(structuredClone(s),t,a).state;
const ready=()=>{let s=change(initial(),'goal',{target:5000,months:12});s=change(s,'coach',{place:'武汉',city:2,home:3,job:6,studentWork:'none',commute:0,rel:0,risk:0,time:0,kidCount:0,incomeNum:2000,rent:0,leisure:400,opening:2000});s.demo=true;return change(s,'coach_route',{index:1});};
const withCase=()=>{const s=demoState();s.cases.push({id:'case-1',purpose:'垫付',date:'2026-11-01',recipient:'小王',amount:100,paid:0,offset:0,kind:'垫付',confirmed:true,transactionId:'sample-loan',dueDate:'2026-11-15',dueType:'agreed',events:[],reminderDays:7});return s;};

// ---- 1. 程序问完"多少元"，用户只回一个数字也要接住 ----
test('预留/申购追问后只回数字，仍生成草案，不落兜底也不重复追问',async()=>{
  const reserve=async(q)=>(await plan(demoState(),q,{intent:'reserve'},null,[],{page:'bills'}));
  for(const [q,want] of [['500','500'],['500元','500'],['一千','1000'],['五百','500']]){
    const r=await reserve(q);
    assert.equal(r.proposal?.type,'reserve',`"${q}" 应生成预留草案`);
    assert.equal(r.proposal.args.amount,want,`"${q}" 金额应为 ${want}`);
    assert.doesNotMatch(r.reply,/没接上/);
  }
  const buy=await plan(demoState(),'1000',{intent:'purchase'},null,[],{page:'bills'});
  assert.equal(buy.proposal?.type,'purchase');
  assert.equal(buy.proposal.args.amount,'1000');
  assert.doesNotMatch(buy.reply,/想模拟申购多少元/,'不能原地重复追问同一句');
  // 说了"大概"这种含糊金额，可以再确认一次确切数，但不能落到没接上。
  const vague=await plan(demoState(),'大概800',{intent:'reserve'},null,[],{page:'bills'});
  assert.doesNotMatch(vague.reply,/没接上/);
  assert.match(vague.reply,/确切金额/);
});

test('等待金额时放宽的裸数字，不会抢走其他流程里的数字',async()=>{
  const time=await plan(demoState(),'3天',{intent:'advance_time'},null,[],{page:'home'});
  assert.equal(time.proposal?.type,'advance_time');
  assert.equal(time.proposal.args.days,3);
  const repay=await plan(withCase(),'40',{intent:'due_repayment',caseId:'case-1'},null,[],{page:'debts'});
  assert.notEqual(repay.proposal?.type,'reserve');
  assert.notEqual(repay.proposal?.type,'purchase');
  const goal=await plan(demoState(),'645',{intent:'goal_details',target:'',months:'',purpose:''},null,[],{page:'home'});
  assert.equal(goal.goalDraft.target,'645');
  const profile=await plan(demoState(),'6000',{intent:'coach_profile',profileDraft:{}},null,[],{page:'goal'});
  assert.notEqual(profile.proposal?.type,'reserve');
});

// ---- 2. 问"导入自己的还是用虚构的"，两个答案都要有出口 ----
test('账单来源两种回答都能走通：导入自己的开导入，虚拟的载入样本',async()=>{
  for(const q of ['导入我自己的账单','导入自己的账单','我要导入账单']){
    const r=await plan(demoState(),q,{intent:'bill_source'},null,[],{page:'bills'});
    assert.equal(r.task?.action,'import-bill',`"${q}" 应打开导入`);
    assert.doesNotMatch(r.reply,/没接上/);
  }
  for(const q of ['虚拟的','用虚构账单','示例账单']){
    const r=await plan(demoState(),q,{intent:'bill_source'},null,[],{page:'bills'});
    assert.equal(r.task?.action,'load-sample-bill',`"${q}" 应载入样例`);
  }
});

// ---- 3. 噪声输入必须给出"下一步怎么答"，不能是死句 ----
test('各等待状态下发噪声，兜底都带上当前该回答什么',async()=>{
  const states=[['bill_source',{intent:'bill_source'}],['transfer_purpose',{intent:'transfer_purpose',transactionId:'sample-loan'}],['people_options',{intent:'people_options',caseId:'case-1'}],['advance_time',{intent:'advance_time'}],['reserve',{intent:'reserve'}],['goal_details',{intent:'goal_details',target:'',months:'',purpose:''}]];
  for(const [name,context] of states){
    for(const q of ['呃','。。。']){
      const r=await plan(withCase(),q,{...context},null,[],{page:'bills'});
      assert.equal(r.inputRecovery,true,`${name} 应走输入兜底`);
      assert.doesNotMatch(r.reply,/这句我没接上。可以重发，或告诉我你想办理哪件事/,'不能只丢一句没接上');
      assert.ok(r.reply.length>18,`${name} 的兜底要给出可答的方向：${r.reply}`);
    }
  }
});

// ---- 4. 首页续说要看目标子屏幕，不能掉回通用推荐 ----
test('首页说"继续"时，目标草稿/方案/预览还在就提示核对，不跳去重新计算',async()=>{
  const context={intent:'goal_details',target:'20000',months:'',purpose:'旅行'};
  const cases=[['goal-review',/核对/],['routes',/选择一条预览/],['route-preview',/预览/],['profile-edit',/继续填写|保留/]];
  for(const [goalScreen,want] of cases){
    const r=await plan(demoState(),'继续',{...context},null,[],{page:'home',goalScreen});
    assert.match(r.reply,want,`首页 ${goalScreen} 应接着目标说：${r.reply}`);
    assert.doesNotMatch(r.reply,/帮我计算三种储蓄方案/);
  }
  const bill=await plan(demoState(),'继续',{intent:'bill_source'},null,[],{page:'home',goalScreen:'routes'});
  assert.doesNotMatch(bill.reply,/三种方案已保留/,'账单流程的续说不能被目标状态抢走');
  // "继续"本身就是"接着刚才"的意思，不能因为页面不是目标页就把目标上下文清掉。
  const stay=await plan(demoState(),'继续',{...context},null,[],{page:'home',goalScreen:'routes'});
  assert.equal(stay.context.intent,'goal_details','说"继续"后目标上下文必须还在');
  const after=await plan(demoState(),'12个月',{...stay.context},null,[],{page:'bills'});
  assert.equal(after.proposal?.type,'goal','续说之后再补期限，仍要能生成草案');
  assert.equal(after.proposal.args.months,12);
});

// ---- 5. 切页面只是看一眼，不能把目标追问清空 ----
test('点导航离开目标页后，目标追问仍在，下一句照旧能接上',async()=>{
  const h=controller(ready());
  await h.driver.act('goal');
  assert.equal(h.driver.dump().agentContext.intent,'goal_details');
  await h.driver.act('nav',{dataset:{page:'home'}});
  assert.equal(h.driver.dump().agentContext.intent,'goal_details','切页面不该清空目标上下文');
  await h.driver.chat('6个月');
  assert.equal(h.driver.dump().pending?.type,'goal','回来后直接答期限应继续目标');
});
