import test from 'node:test';
import assert from 'node:assert/strict';
import {initial} from '../lib/domain.mjs';
import {plan} from '../lib/agent.mjs';
import {cnNumber} from '../lib/goal-intent.mjs';

// 系统刚问完"你想攒多少钱，打算多久攒到？"，用户先报用途是最自然的回答。
const asking = {intent: 'goal_details', target: '', months: '', purpose: ''};
const answer = message => plan(initial(), message, {...asking}, null, [], {page: 'goal', goalScreen: 'goal-edit'});

test('只报用途也要接住，并追问缺的金额与期限', async () => {
  for (const [message, purpose] of [['买车', '买车'], ['买电脑', '买电脑'], ['换个手机', '换个手机'], ['想去旅游', '旅游'], ['为了结婚', '结婚'], ['我要买车', '买车']]) {
    const r = await answer(message);
    assert.equal(r.inputRecovery, undefined, `"${message}" 是用途，不该落到"没接上"`);
    assert.doesNotMatch(r.reply, /没接上/, `"${message}" 不该兜底`);
    assert.equal(r.goalDraft.purpose, purpose, `"${message}" 应记下用途`);
    assert.match(r.reply, /已记下用途/, `"${message}" 应先确认用途`);
    assert.match(r.reply, /攒多少钱|多久攒到/, `"${message}" 还要追问缺的那一项`);
  }
});

test('用途加金额和期限时直接生成草案，不再被"多余的字"拦住', async () => {
  for (const message of ['买电脑 5000元 6个月', '为了买房，5000元，6个月', '5000元买电脑 6个月', '我想攒5000元买电脑，6个月', '买车 5000元 6个月']) {
    const r = await answer(message);
    assert.equal(r.proposal?.type, 'goal', `"${message}" 应生成目标草案`);
    assert.equal(r.proposal.args.target, '5000', `"${message}" 金额`);
    assert.equal(r.proposal.args.months, 6, `"${message}" 期限`);
    assert.ok(r.proposal.args.name, `"${message}" 用途不该为空`);
  }
});

test('口语金额和口语省位都能认', async () => {
  for (const message of ['大概五万', '大概五万吧', '五万左右', '五万', '五万']) {
    const r = await answer(message);
    assert.equal(r.inputRecovery, undefined, `"${message}" 不该兜底`);
    assert.equal(r.goalDraft.target, '50000', `"${message}" 应识别为 50000`);
  }
  const full = await answer('大概五万，一年');
  assert.equal(full.proposal.args.target, '50000');
  assert.equal(full.proposal.args.months, 12);
  assert.equal(cnNumber('一万二'), 12000, '"一万二"是一万二不是一万零二');
  assert.equal(cnNumber('三万五'), 35000);
  assert.equal(cnNumber('十万五'), 105000);
  assert.equal(cnNumber('一万二千'), 12000);
});

test('金额区间仍然要求给一个明确数字', async () => {
  for (const message of ['5000到8000', '五千到八千', '5000或6000元']) {
    const r = await answer(message);
    assert.equal(r.clarification, true, `"${message}" 应要求明确金额`);
    assert.equal(r.proposal, null);
    assert.equal(r.goalDraft.target, '', `"${message}" 不能自己挑一个端点`);
    assert.match(r.reply, /明确金额/);
  }
});

test('跑题的话仍然兜底，闸门没有被放宽成什么都接', async () => {
  for (const message of ['今天天气不错', '食堂排队人好多', '车', '上课签到200元，第6个月']) {
    const r = await answer(message);
    assert.equal(r.inputRecovery, true, `"${message}" 与目标无关，应走兜底`);
    assert.match(r.reply, /没接上/);
    assert.equal(r.proposal, null);
  }
});

test('说"还没想好"不再报没接上，而是给一个能往下走的建议', async () => {
  for (const message of ['随便吧', '我还没想好', '不知道']) {
    const r = await answer(message);
    assert.equal(r.inputRecovery, undefined, `"${message}" 不该说没接上`);
    assert.doesNotMatch(r.reply, /没接上/);
    assert.match(r.reply, /先估|每月能存下/, `"${message}" 应给建议`);
  }
});
