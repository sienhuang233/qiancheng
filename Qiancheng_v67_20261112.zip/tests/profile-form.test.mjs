// 对话内「现实条件」表单：填表 → 拼成一句话 → 服务端正则还原。
// 这条往返链路是合队友方案的关键：表单不能有自己的一套解析，否则两处会说不一致的话。
import test from 'node:test';
import assert from 'node:assert/strict';
import {profileTemplateValues,profileTemplateSentence,PROFILE_CHOICES,profileDraftSentence,PROFILE_FIELDS} from '../public/engines/profile.mjs';
import {extractProfile} from '../lib/coach-agent.mjs';
import {CITY_TIERS,tierForPlace,TIER_LABELS} from '../public/engines/cities.mjs';
import {BASE} from '../public/engines/goal.mjs';

// 表单值 → 句子 → 服务端 drafts，返回还原后的字段
const roundTrip=v=>extractProfile(profileTemplateSentence(v)).draft;

test('表单值往返：七个字段填什么，服务端就还原成什么',()=>{
  const cases=[
    {place:'宁波',job:'0',home:'0',rel:'0',income:'8000',rent:'1800',opening:'3000'},
    {place:'武汉',job:'6',home:'3',rel:'1',income:'2000',rent:'0',opening:'2000'},
    {place:'厦门',job:'4',home:'1',rel:'2',income:'12000',rent:'3000',opening:'50000'},
    {place:'昆山',job:'2',home:'2',rel:'3',income:'7000',rent:'0',opening:'0'},
    {place:'拉萨',job:'5',home:'1',rel:'0',income:'9000',rent:'2000',opening:'8000'}
  ];
  for(const v of cases){
    const d=roundTrip(v);
    assert.equal(d.place,v.place,`城市丢了：${v.place}`);
    assert.equal(d.job,Number(v.job),`身份对不上：${JSON.stringify(v)}`);
    assert.equal(d.home,Number(v.home),`住房对不上：${JSON.stringify(v)}`);
    assert.equal(d.rel,Number(v.rel),`家庭阶段对不上：${JSON.stringify(v)}`);
    assert.equal(d.incomeNum,Number(v.income),'收入对不上');
    assert.equal(d.rent,Number(v.rent),'房租对不上');
    assert.equal(d.opening,Number(v.opening),'存款对不上');
  }
});

test('每个选项值都能还原：改了选项顺序或语料，这里立刻失败',()=>{
  for(const [name,rows] of Object.entries(PROFILE_CHOICES)){
    for(const [value] of rows){
      const d=roundTrip({[name]:String(value)});
      assert.equal(d[name],Number(value),`${name}=${value} 经表单走一圈后没还原`);
    }
  }
});

test('只填一项也能发：空字段不硬塞示例值',()=>{
  const s=profileTemplateSentence({place:'成都'});
  assert.equal(s,'我在成都');
  const d=extractProfile(s).draft;
  assert.equal(d.place,'成都');
  assert.equal(d.incomeNum,undefined,'没填的收入不能凭空出现');
});

test('全空时返回空串，调用方据此拦住提交',()=>{
  assert.equal(profileTemplateSentence({}),'');
  assert.equal(profileTemplateSentence({place:'  '}),'');
});

test('学生说生活费，不写月薪；住宿舍的房租不编成 1800',()=>{
  const v={place:'武汉',job:'6',home:'3',income:'2000',rent:'0'};
  const s=profileTemplateSentence(v);
  assert.match(s,/每月生活费 2000/);
  assert.doesNotMatch(s,/月薪/);
  assert.match(s,/房租 0/);
});

test('表单初始值：已有真实值优先，缺项才用示例值',()=>{
  const filled=profileTemplateValues({place:'南京',job:0,home:0,rel:0,incomeNum:9000,rent:2200,opening:15000});
  assert.equal(filled.place,'南京');
  assert.equal(filled.job,'0');
  assert.equal(filled.income,'9000');
  assert.equal(filled.rent,'2200');
  assert.equal(filled.opening,'15000');
  const empty=profileTemplateValues({});
  assert.equal(empty.place,'深圳');
  assert.equal(empty.income,'8000');
  assert.equal(empty.opening,'3000');
  const dorm=profileTemplateValues({job:6,home:3});
  assert.equal(dorm.rent,'0','住宿舍的示例房租必须是 0');
  assert.equal(dorm.student,true);
});

test('城市档位表与引擎的四档严格对齐，不会取到空档',()=>{
  const vals=[...new Set(Object.values(CITY_TIERS))].sort();
  assert.deepEqual(vals,[0,1,2,3],'档位必须落在 0—3');
  assert.equal(TIER_LABELS.length,BASE.city.length,'档位名称数量要与 BASE.city 一致');
  for(const v of Object.values(CITY_TIERS))assert.ok(BASE.city[v],`BASE.city[${v}] 不存在`);
});

test('常见城市分档合理：一线核心、一线其他、新一线、二三线各不相同',()=>{
  assert.equal(tierForPlace('深圳南山'),0);
  assert.equal(tierForPlace('北京'),0);
  assert.equal(tierForPlace('深圳'),1);
  assert.equal(tierForPlace('广州'),1);
  assert.equal(tierForPlace('宁波'),2);
  assert.equal(tierForPlace('厦门'),3);
  assert.equal(tierForPlace('昆山'),3);
  assert.equal(tierForPlace('拉萨'),3);
  assert.equal(tierForPlace(''),null,'空城市不猜档位');
});

test('只给省份时按二三线，且不越界',()=>{
  assert.equal(tierForPlace('浙江'),3);
  assert.equal(tierForPlace('某个没登记的地方'),3);
});

test('说去某地旅游不算住在那里：档位不能被游玩地点带偏',()=>{
  for(const q of ['我想攒钱去大理旅游','计划明年去厦门玩','想去三亚度个假']){
    const d=extractProfile(q).draft;
    assert.equal(d.place,undefined,`"${q}" 不该被识别成居住地`);
  }
  assert.equal(extractProfile('在北京上班，月薪一万').draft.city,0,'有地点引导词时才认');
});

test('表单和草稿句用的是同一套语料，不会说出两种口径',()=>{
  // 全缺条件时草稿句给示例值，表单也预填同样的示例值
  const draft=profileDraftSentence(PROFILE_FIELDS,{});
  const values=profileTemplateValues({});
  for(const word of ['深圳','8000','1800']){
    assert.match(draft,new RegExp(word),`草稿句应含 ${word}`);
    assert.ok(Object.values(values).includes(word),`表单预填也应含 ${word}`);
  }
});
