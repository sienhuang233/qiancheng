import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {initial,apply,summary} from '../lib/domain.mjs';
import {prov,isKnownProvKey,provenanceDrawer,ASSUMPTIONS} from '../public/provenance-ui.mjs';
import {analyzeBills} from '../public/engines/bill-analysis.mjs';
import {CAT_NAME} from '../public/engines/classifier.mjs';
import {coachScenario} from '../public/engines/coach-scenario.mjs';
import {executionPlan} from '../public/engines/plan.mjs';
import {simulate} from '../public/engines/goal.mjs';
import {coachResult} from '../public/coach-ui.mjs';
import {billAnalysisReport} from '../public/bill-ui.mjs';

const change=(s,type,args={})=>apply(structuredClone(s),type,args).state;
const view=s=>({state:s,summary:summary(s)});
const student={place:'武汉',city:2,home:3,job:6,studentWork:'none',commute:0,rel:0,risk:0,time:0,kidCount:0,incomeNum:2000,rent:0,leisure:400,extraAmt:0,opening:2000};
const ready=()=>change(change(change(initial(),'goal',{target:'5000',months:8}),'coach',student),'coach_route',{index:1});
const money=n=>'¥'+(n/100).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
const pct=p=>(Math.round(p*1000)/10)+'%';
const drawer=(data,key)=>provenanceDrawer(data,key);

test('可点数字带 data-prov、键盘可达，不写成按钮', () => {
  const html=prov('metric:cash','¥1,000.00');
  assert.match(html,/data-prov="metric:cash"/);
  assert.match(html,/role="button"/);
  assert.match(html,/tabindex="0"/);
  assert.match(html,/title="查看这个数字从哪里来"/);
  assert.doesNotMatch(html,/<button/,'不用按钮，避免混进 data-act 的分发表');
});

test('只放行登记过来源的 key，防止点了给不出解释', () => {
  for(const k of ['metric:cash','metric:expense','metric:receivable','metric:available','bill:total','bill:protected','bill:pending','bill:cat:food','goal:prob','goal:plan:0:save','plan:monthly','plan:weekly','plan:daily','plan:living'])assert.equal(isKnownProvKey(k),true,k);
  for(const k of ['metric:','bill:','plan:unknown','goal:plan:3:prob','bill:cat:','random'])assert.equal(isKnownProvKey(k),false,k);
});

test('账单总额的来源与程序算出的金额一致，四类来源都分开列', () => {
  const s=change(initial(),'sample_bill',{}),data=view(s),rep=analyzeBills(s,data.summary.period);
  const html=drawer(data,'bill:total');
  assert.match(html,/本期已确认消费/);
  for(const n of ['①','②','③','④'])assert.match(html,new RegExp(n));
  assert.match(html,/你的数据/);
  assert.match(html,/程序假设/);
  assert.match(html,/待核实/);
  assert.match(html,new RegExp(money(rep.totalCents).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  assert.match(html,/共 \d+ 笔消费/);
});

test('期初未知时，现金与可用资金都把"未知"列进待核实，而不是编一个 0', () => {
  const s=initial(),data=view(s);
  assert.match(drawer(data,'metric:cash'),/未知/);
  assert.match(drawer(data,'metric:available'),/期初现金/);
  const html=drawer(data,'metric:cash');
  assert.match(html,/这一项不含任何估计参数/);
});

test('达标比例的来源用真实模拟数字，不是抄在文案里的固定值', () => {
  const data=view(ready()),sc=coachScenario({state:data.state,summary:data.summary});
  assert.ok(sc,'夹具应当能算出方案');
  const html=drawer(data,'goal:prob');
  assert.match(html,new RegExp('2000 条路径里有 '+sc.result.natural.sim.hits+' 条'));
  assert.match(html,new RegExp(pct(sc.result.natural.sim.prob).replace('%','%')));
  assert.match(html,/未校准估计/);
  assert.match(html,/不是你个人的真实成功概率/);
  const plan0=drawer(data,'goal:plan:0:prob');
  assert.match(plan0,new RegExp(sc.result.plans[0].name+'方案'));
  assert.match(plan0,new RegExp(pct(sc.result.plans[0].prob)));
});

test('周额度说明里写的是真实的 52/12 周，不是手写的 4 周', () => {
  const data=view(ready()),p=executionPlan({state:data.state,summary:data.summary});
  assert.ok(p,'夹具应当有执行计划');
  const html=drawer(data,'plan:weekly');
  assert.match(html,/÷ 4\.33 周/);
  assert.doesNotMatch(html,/÷ 4 周/);
  assert.match(html,new RegExp(money(p.weeklyCents).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
  assert.match(drawer(data,'plan:daily'),/30\.4 天/);
});

test('分类金额能对上具体分类：key 切分不能掉字符', () => {
  const s=change(initial(),'sample_bill',{}),data=view(s),rep=analyzeBills(s,data.summary.period);
  const first=rep.categories[0];
  assert.ok(first,'样本账单应当有分类');
  const html=drawer(data,'bill:cat:'+first.cat);
  const label=CAT_NAME[first.cat]||first.cat;
  assert.match(html,new RegExp('分类金额 · '+label),'标题要显示分类名，不能是截断的尾巴');
  assert.doesNotMatch(html,/分类金额 · [a-z]?ood/);
  assert.match(html,/当前显示 <b>/);
  assert.doesNotMatch(html,/当前显示 <b>—<\/b>/,`分类 ${first.cat} 应当有金额`);
});

test('没登记的数字老老实实说没登记，不硬编来源', () => {
  const html=drawer(view(initial()),'plan:living');
  assert.match(html,/这个数字暂未登记来源|还没有选定路线/);
  assert.match(drawer(view(initial()),'bill:cat:notacat'),/这个分类|没有这个分类/);
});

test('打开溯源不改变任何状态', () => {
  const data=view(ready()),before=JSON.stringify(data.state);
  for(const k of ['goal:prob','goal:plan:0:save','plan:monthly','plan:weekly','plan:daily','metric:cash','metric:available'])drawer(data,k);
  assert.equal(JSON.stringify(data.state),before);
});

test('界面上真的把这些数字做成了可点入口，而不只是后端能生成抽屉', () => {
  const data=view(ready());
  const coach=coachResult(data,null,true);
  assert.match(coach,/data-prov="goal:prob"/,'主达标的比例要能点开');
  assert.match(coach,/data-prov="goal:plan:0:prob"/,'每条路线的比例要能点开');
  assert.match(coach,/data-prov="goal:plan:0:save"/,'每条路线的月存额要能点开');
  const bill=change(initial(),'sample_bill',{}),bv=view(bill);
  const report=billAnalysisReport(bv,bv.summary.period);
  for(const k of ['bill:total','bill:protected','bill:pending'])assert.match(report,new RegExp(`data-prov="${k}"`),k);
  assert.match(report,/data-prov="bill:cat:/,'分类金额要能点开');
});

test('可点数字被包在原来的元素里，标签结构不被改写', () => {
  const html=coachResult(view(ready()),null,true);
  // 大数字仍在 .probability-number 内，避免破坏原有字号与布局
  assert.match(html,/class="probability-number[^"]*"><span class="prov" role="button" tabindex="0" data-prov="goal:prob"/);
});

test('假设面板的数字与引擎源码一致：改了参数就会在这里失败', () => {
  const src=readFileSync(new URL('../public/engines/goal.mjs',import.meta.url),'utf8');
  const A=Object.fromEntries(ASSUMPTIONS.map(x=>[x.id,x]));
  assert.match(src,/const FLEX_SLIP=0\.12;/);
  assert.equal(A.slip.value,'12%');
  assert.match(src,/const INFL=0\.03\/12;/);
  assert.equal(A.infl.value,'3%/年');
  assert.match(src,/N=2000/);
  assert.equal(A.paths.value,'2000 条');
  assert.match(src,/const LAYOFF=\[0\.08,0\.04,0\.05,0\.09,0\.01,0\.12,0\.06\]/);
  assert.match(A.layoff.value,/1%–12%/);
  // 模拟真的跑 2000 条路径，不是文案里写的
  assert.equal(simulate(1000,12,1,30000).paths,2000);
  // 波动率表：科技 18% 到自由职业 35%，在校 6%
  assert.match(src,/互联网\/科技',0\.18,0\.06/);
  assert.match(src,/自由职业\/创业',0\.35/);
  const html=drawer(view(ready()),'goal:prob');
  for(const t of ['模拟路径数量','收入波动','收入中断','弹性超支','支出通胀','偶发开销','大额支出','投资收益'])assert.match(html,new RegExp(t),t);
});
