// 第二步「现实条件」：进对话时自动生成一句待补草稿，用户只改数字。
import test from 'node:test';
import assert from 'node:assert/strict';
import {profileDraftSentence,missingProfile,PROFILE_FIELDS} from '../public/engines/profile.mjs';
import {initial,apply} from '../lib/domain.mjs';
import {controller} from './helpers/controller.mjs';

const ready=()=>apply(structuredClone(initial()),'goal',{target:5000,months:12}).state;

test('草稿句：条件全缺时用常见示例值，且是一句完整可发送的话',()=>{
  const s=profileDraftSentence(PROFILE_FIELDS,{});
  assert.match(s,/^我在深圳/);
  assert.match(s,/月薪 8000/);
  assert.match(s,/房租 1800/);
  assert.match(s,/。$/);
});

test('草稿句：已有条件用真实值，不再回落到示例值',()=>{
  const s=profileDraftSentence(['rent'],{place:'武汉',job:0,home:0,incomeNum:9000,rel:0});
  assert.match(s,/我在武汉/);
  assert.match(s,/月薪 9000/);
  assert.doesNotMatch(s,/8000/,'已有收入不能再用示例 8000');
  assert.match(s,/房租 1800/,'缺房租时给示例值，由用户改数字');
});

test('草稿句：在校学生说生活费，住宿舍不编房租',()=>{
  const s=profileDraftSentence(['incomeNum'],{place:'武汉',job:6,home:3,rent:0,rel:0});
  assert.match(s,/在校读书/);
  assert.match(s,/每月生活费/);
  assert.doesNotMatch(s,/月薪/);
  const dorm=profileDraftSentence(['rent'],{place:'武汉',job:6,home:3,incomeNum:2000,rel:0});
  assert.match(dorm,/房租 0/,'住宿舍时房租示例为 0，不塞一个不存在的支出');
});

test('第二步进入时在对话里给出预填好的表单，不再把长句塞进输入框',()=>{
  const h=controller(ready());
  h.driver.begin();
  h.driver.render();
  const form=h.driver.dump().messages.find(m=>m.form==='profile');
  assert.ok(form,'条件不全时应插入现实条件表单');
  assert.ok(form.formValues.place,'城市要有预填值，用户只改数字');
  assert.ok(form.formValues.income,'收入要有预填值');
  assert.equal(h.input.value,'','默认路径不塞长草稿句，避免和表单抢入口');
  assert.match(h.mount.innerHTML,/data-form="profile-template"/);
  assert.match(h.mount.innerHTML,/value="深圳"/,'表单里的城市应已填好');
});

test('条件已齐时不插表单，也不留草稿',()=>{
  const s=ready();
  s.coach={place:'武汉',city:2,home:3,job:6,studentWork:'none',commute:0,rel:0,risk:0,time:0,kidCount:0,incomeNum:2000,rent:0,leisure:400,opening:2000};
  s.demo=true;s.openingKnown=true;
  assert.equal(missingProfile(s,s.coach).length,0,'前置条件：这份 state 已经完整');
  const h=controller(s);
  h.driver.begin();
  h.driver.render();
  assert.equal(h.input.value,'');
  assert.equal(h.driver.dump().messages.filter(m=>m.form==='profile').length,0,'条件齐了不该再出表单');
  assert.doesNotMatch(h.mount.innerHTML,/composer-tip/);
});

test('选「改用逐句回答」才把草稿句填进输入框，并收起表单',async()=>{
  const h=controller(ready());
  h.driver.begin();
  h.driver.render();
  await h.driver.act('profile-step',{dataset:{}});
  h.driver.render();
  assert.ok(h.input.value.length>0,'输入框应被填入草稿');
  assert.match(h.input.value,/我在/);
  assert.match(h.input.value,/房租/);
  assert.match(h.mount.innerHTML,/composer-tip/,'应显示草稿提示条');
  assert.equal(h.driver.dump().messages.filter(m=>m.form==='profile').length,0,'表单应已收起');
});

test('用户已经在输入时，切回逐句回答不覆盖、不抢草稿位',async()=>{
  const h=controller(ready());
  h.input.value='我已经在打字了';
  h.driver.begin();
  h.driver.render();
  await h.driver.act('profile-step',{dataset:{}});
  assert.equal(h.input.value,'我已经在打字了','不能覆盖用户正在写的内容');
  assert.doesNotMatch(h.mount.innerHTML,/composer-tip/,'没用到草稿就不该显示提示条');
});
