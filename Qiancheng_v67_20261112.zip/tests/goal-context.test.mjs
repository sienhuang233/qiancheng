import test from 'node:test';
import assert from 'node:assert/strict';
import {initial} from '../lib/domain.mjs';
import {plan} from '../lib/agent.mjs';
import {looksLikeGoalAnswer} from '../lib/goal-intent.mjs';
import {resolveModelIntent} from '../lib/model-intent.mjs';

// 用户在首页说话，但上一句是目标的追问。目标上下文不能因为"当前页面不是目标页"就被清掉。
const asking = {intent: 'goal_details', target: '', months: '', purpose: ''};
const home = (message, context = asking) => plan(initial(), message, {...context}, null, [], {page: 'home'});

test('首页回答"买车 / 645 / 6个月"仍算目标回答，不落到没接上', async () => {
  for (const message of ['买车', '645', '6个月', '645202', '半年']) {
    const r = await home(message);
    assert.equal(r.inputRecovery, undefined, `"${message}" 不该走兜底`);
    assert.doesNotMatch(r.reply, /没接上|我还需要核对/, `"${message}" 不该报没接上`);
    assert.equal(r.goalDraft !== undefined, true, `"${message}" 应留在目标流程里`);
  }
  const purpose = await home('买车');
  assert.equal(purpose.goalDraft.purpose, '买车');
  const amount = await home('645');
  assert.equal(amount.goalDraft.target, '645');
});

test('改口说新金额要覆盖旧金额，不能沿用上一个数', async () => {
  const first = await home('645', {...asking, purpose: '买车'});
  assert.equal(first.goalDraft.target, '645');
  const second = await home('645202', {...first.context});
  assert.equal(second.goalDraft.target, '645202', '第二个数字应替换第一个');
  assert.equal(second.goalDraft.purpose, '买车', '改金额不该丢掉已记的用途');
  const done = await home('6个月', {...second.context});
  assert.equal(done.proposal?.type, 'goal');
  assert.equal(done.proposal.args.target, '645202');
  assert.equal(done.proposal.args.months, 6);
});

test('换成别的问题时目标上下文照旧清掉，不抢别的流程', async () => {
  for (const message of ['我的余额还有多少', '帮我分析账单', '今天天气不错']) {
    const r = await plan(initial(), message, {...asking}, null, [], {page: 'bills'});
    assert.equal(r.context?.intent, undefined, `"${message}" 应清掉目标上下文`);
  }
});

test('模型把旧金额当证据时，规则解析出的新金额优先', () => {
  const context = {intent: 'goal_details', target: '645', months: '', purpose: ''};
  const fallback = {mode: 'rules', reply: '', steps: [], proposal: null, next: 'goal_followup', clarification: true, context, goalDraft: {target: '645202', months: '', purpose: ''}};
  // "645" 是 "645202" 的子串，模型可能据此把旧金额 645 当成这句话的证据。
  const r = resolveModelIntent(initial(), '645202', context, {intent: 'goal', goal_target: {value: 645, quote: '645'}}, fallback, () => fallback);
  assert.equal(r.goalDraft.target, '645202', '不能被模型拉回旧金额');
});

test('looksLikeGoalAnswer 只认金额、期限和用途', () => {
  for (const q of ['645', '645202', '5000', '大概五万', '五万左右', '6个月', '一年', '半年', '买车', '买车 5000元 6个月']) {
    assert.equal(looksLikeGoalAnswer(q), true, `"${q}" 是目标回答`);
  }
  for (const q of ['分析账单', '我的余额还有多少', '今天天气不错', '帮我核对这笔转账', '']) {
    assert.equal(looksLikeGoalAnswer(q), false, `"${q}" 不是目标回答`);
  }
});
